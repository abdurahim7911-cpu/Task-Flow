# TaskFlow — Project Management System

Foundation project of the Fullstack graduation system. Users create projects, break them into tasks, assign them, and track progress and overdue work on a dashboard.

## Features

- Register, login, forgot/reset password, profile (name and password change)
- JWT authentication, bcrypt password hashing, protected routes (frontend and backend)
- Roles: **User** and **Admin** (admin can list all users and projects, read-only)
- Projects: create, view, update, delete (owner only), search and status filter
- Tasks inside projects: create, edit, delete, assign to a user, move between To do / In progress / Done
- Dashboard: total projects, total tasks, to do, in progress, done, overdue; searchable and filterable task list
- Loading, error, empty and success states everywhere; responsive layout (mobile, tablet, desktop)

## Business rules (enforced on the server)

1. Only the project owner can delete the project.
2. A user can only manage their own projects (and the tasks inside them).
3. A task always belongs to an existing project.
4. Deadlines must be valid dates.
5. Required fields cannot be empty (zod validation).
6. Protected routes need a valid JWT.

Overdue means: deadline is before today (UTC) and the task is not done.

## Tech

Frontend: React 18, Vite, React Router DOM, Tailwind CSS, Axios, Lucide React
Backend: Node.js, Express, REST API, JWT, bcryptjs, zod, helmet, cors, express-rate-limit, dotenv
Database: PostgreSQL with Prisma ORM

## Project structure

```
backend/   Express API (routes → middleware → controllers → Prisma)
frontend/  React app (pages, components, context, api client)
```

## Installation

Requirements: Node.js 18+, a PostgreSQL database (local or cloud, e.g. Neon, Supabase, Railway).

### Backend

```bash
cd backend
cp .env.example .env        # then edit DATABASE_URL and JWT_SECRET
npm install
npx prisma migrate dev --name init
npm run seed                # optional: creates the admin user
npm run dev                 # http://localhost:5000
```

### Frontend

```bash
cd frontend
cp .env.example .env        # VITE_API_URL=http://localhost:5000/api
npm install
npm run dev                 # http://localhost:5173
```

## Environment variables

Backend (`backend/.env`):

| Name | Description |
|---|---|
| PORT | API port (default 5000) |
| NODE_ENV | development or production |
| DATABASE_URL | PostgreSQL connection string |
| JWT_SECRET | Long random secret for signing tokens |
| JWT_EXPIRES_IN | Token lifetime, e.g. 7d |
| CLIENT_URL | Allowed frontend origin(s) for CORS, comma-separated |
| ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD | Used by `npm run seed` |

Frontend (`frontend/.env`): `VITE_API_URL` — base URL of the API.

Never commit `.env` files (they are in `.gitignore`).

## Password reset

No email service is wired up. In development, `POST /api/auth/forgot-password` returns `devResetToken` and the UI links straight to the reset page. In production the token is never returned; connect an email provider in `auth.controller.js` (`forgotPassword`) to send the link.

## API

Base URL: `/api`. Protected endpoints need `Authorization: Bearer <token>`.
Errors look like `{ "success": false, "message": "...", "errors": [{ "field": "...", "message": "..." }] }`.

| Method | URL | Auth | Body / query | Success response |
|---|---|---|---|---|
| POST | /auth/register | – | name, email, password | 201 `{ token, user }` |
| POST | /auth/login | – | email, password | 200 `{ token, user }` |
| POST | /auth/forgot-password | – | email | 200 `{ message, devResetToken? }` |
| POST | /auth/reset-password | – | token, password | 200 `{ message }` |
| GET | /users/me | JWT | – | `{ user }` |
| PATCH | /users/me | JWT | name?, currentPassword?, newPassword? | `{ user }` |
| GET | /users | JWT | – | `{ users: [{ id, name }] }` |
| GET | /dashboard/stats | JWT | – | `{ stats: { totalProjects, totalTasks, todo, inProgress, done, overdue } }` |
| GET | /projects | JWT | ?search, ?status | `{ projects }` |
| POST | /projects | JWT | title, description?, status?, deadline? | 201 `{ project }` |
| GET | /projects/:id | JWT (owner) | – | `{ project }` |
| PATCH | /projects/:id | JWT (owner) | any project field | `{ project }` |
| DELETE | /projects/:id | JWT (owner) | – | `{ message }` |
| GET | /projects/:id/tasks | JWT (owner) | ?search, ?status, ?priority, ?overdue | `{ tasks }` |
| POST | /projects/:id/tasks | JWT (owner) | title, description?, status?, priority?, deadline?, assignedUserId? | 201 `{ task }` |
| GET | /tasks | JWT | ?search, ?status, ?priority, ?projectId, ?overdue=true | `{ tasks }` |
| PATCH | /tasks/:id | JWT (owner) | any task field | `{ task }` |
| DELETE | /tasks/:id | JWT (owner) | – | `{ message }` |
| GET | /admin/users | JWT + ADMIN | – | `{ users }` |
| GET | /admin/projects | JWT + ADMIN | – | `{ projects }` |

Status codes: 400 validation, 401 not authenticated, 403 not allowed (for example deleting someone else's project), 404 not found, 409 duplicate email, 429 rate limit.

Enums: project status `ACTIVE | COMPLETED | ARCHIVED`; task status `TODO | IN_PROGRESS | DONE`; priority `LOW | MEDIUM | HIGH`.

## Deployment

- Database: Neon / Supabase / Railway PostgreSQL → copy the connection string to `DATABASE_URL`.
- Backend (Render or Railway): root directory `backend`, build `npm install && npx prisma migrate deploy`, start `npm start`. Set the env vars above, with `NODE_ENV=production` and `CLIENT_URL` = your frontend URL.
- Frontend (Vercel): root directory `frontend`, build `npm run build`, output `dist`, env `VITE_API_URL=https://<your-backend>/api`. `vercel.json` already contains the SPA rewrite.

## Screenshots / links

- Screenshots: _add after running the app_
- Demo: _add your deployed URL_
- GitHub: _add your repository URL_
