import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const email = (process.env.ADMIN_EMAIL || 'admin@taskflow.local').toLowerCase();
const password = process.env.ADMIN_PASSWORD || 'Admin12345';

const existing = await prisma.user.findUnique({ where: { email } });
if (existing) {
  console.log(`Admin already exists: ${email}`);
} else {
  await prisma.user.create({
    data: {
      name: process.env.ADMIN_NAME || 'Admin',
      email,
      password: await bcrypt.hash(password, 12),
      role: 'ADMIN',
    },
  });
  console.log(`Admin created: ${email}`);
}
await prisma.$disconnect();
