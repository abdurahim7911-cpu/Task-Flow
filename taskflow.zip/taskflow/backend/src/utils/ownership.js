import { prisma } from '../config/prisma.js';
import { ApiError } from './ApiError.js';

// Business rules 1 & 2: a user can only manage their own projects.
export const getOwnedProject = async (projectId, userId) => {
  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) throw ApiError.notFound('Project not found');
  if (project.ownerId !== userId) throw ApiError.forbidden('This project belongs to another user');
  return project;
};

// Business rule 3: a task always belongs to an existing project; ownership flows through it.
export const getOwnedTask = async (taskId, userId) => {
  const task = await prisma.task.findUnique({ where: { id: taskId }, include: { project: true } });
  if (!task) throw ApiError.notFound('Task not found');
  if (task.project.ownerId !== userId) throw ApiError.forbidden('This task belongs to another user\'s project');
  return task;
};

export const assertUserExists = async (userId) => {
  if (!userId) return;
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { id: true } });
  if (!user) throw ApiError.badRequest('Assigned user does not exist');
};

// Overdue = deadline before the start of today (UTC) and not done.
export const startOfToday = () => {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  return d;
};
