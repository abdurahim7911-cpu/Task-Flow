import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

import routes from './routes/index.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';

const app = express();

/* =========================
   SECURITY
========================= */

app.use(helmet());

/* =========================
   CORS
========================= */

app.use(
  cors({
    origin: [
      'http://localhost:5173',
      'http://localhost:5174',
    ],
    methods: [
      'GET',
      'POST',
      'PUT',
      'PATCH',
      'DELETE',
      'OPTIONS',
    ],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
    ],
    credentials: true,
  })
);

/* =========================
   BODY PARSER
========================= */

app.use(
  express.json({
    limit: '100kb',
  })
);

/* =========================
   GENERAL API RATE LIMIT
========================= */

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,

  standardHeaders: true,
  legacyHeaders: false,

  message: {
    success: false,
    message: 'Too many requests. Please try again later.',
  },

  // Login va register o‘zining alohida limiteriga ega.
  skip: (req) => {
    return (
      req.path === '/auth/login' ||
      req.path === '/auth/register'
    );
  },
});

app.use('/api', apiLimiter);

/* =========================
   HEALTH CHECK
========================= */

app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    status: 'ok',
  });
});

/* =========================
   API ROUTES
========================= */

app.use('/api', routes);

/* =========================
   404 HANDLER
========================= */

app.use(notFound);

/* =========================
   GLOBAL ERROR HANDLER
========================= */

app.use(errorHandler);

export default app;