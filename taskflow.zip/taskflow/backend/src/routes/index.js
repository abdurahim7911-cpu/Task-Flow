import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, validateQuery } from '../middleware/validate.js';
import * as v from '../validators/index.js';
import * as auth from '../controllers/auth.controller.js';
import * as users from '../controllers/user.controller.js';
import * as projects from '../controllers/project.controller.js';
import * as tasks from '../controllers/task.controller.js';
import * as dashboard from '../controllers/dashboard.controller.js';
import * as admin from '../controllers/admin.controller.js';

const router = Router();

// Auth (rate limited against brute force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Try again in a few minutes.' },
});
router.post('/auth/register', authLimiter, validate(v.registerSchema), auth.register);
router.post('/auth/login', authLimiter, validate(v.loginSchema), auth.login);
router.post('/auth/forgot-password', authLimiter, validate(v.forgotPasswordSchema), auth.forgotPassword);
router.post('/auth/reset-password', authLimiter, validate(v.resetPasswordSchema), auth.resetPassword);

// Everything below requires a valid JWT
router.use(authenticate);

router.get('/users/me', users.getMe);
router.patch('/users/me', validate(v.updateProfileSchema), users.updateMe);
router.get('/users', users.listUsers);

router.get('/dashboard/stats', dashboard.getStats);

router.get('/projects', validateQuery(v.projectQuerySchema), projects.listProjects);
router.post('/projects', validate(v.createProjectSchema), projects.createProject);
router.get('/projects/:id', projects.getProject);
router.patch('/projects/:id', validate(v.updateProjectSchema), projects.updateProject);
router.delete('/projects/:id', projects.deleteProject);
router.get('/projects/:id/tasks', validateQuery(v.taskQuerySchema), tasks.listProjectTasks);
router.post('/projects/:id/tasks', validate(v.createTaskSchema), tasks.createTask);

router.get('/tasks', validateQuery(v.taskQuerySchema), tasks.listMyTasks);
router.patch('/tasks/:id', validate(v.updateTaskSchema), tasks.updateTask);
router.delete('/tasks/:id', tasks.deleteTask);

router.get('/admin/users', authorize('ADMIN'), admin.listAllUsers);
router.get('/admin/projects', authorize('ADMIN'), admin.listAllProjects);

export default router;
