import { z } from 'zod';

const trimmed = (min, max, label) =>
  z.string({ required_error: `${label} is required` }).trim()
    .min(min, `${label} must be at least ${min} characters`)
    .max(max, `${label} must be at most ${max} characters`);

export const emailField = z.string({ required_error: 'Email is required' }).trim().toLowerCase().email('Enter a valid email address');

export const passwordField = z.string({ required_error: 'Password is required' })
  .min(8, 'Password must be at least 8 characters')
  .max(72, 'Password must be at most 72 characters')
  .regex(/[A-Za-z]/, 'Password must contain a letter')
  .regex(/[0-9]/, 'Password must contain a number');

// Accepts "2025-12-31" or a full ISO date, returns a Date. Empty string / null clears the value.
const deadlineField = z.preprocess(
  (v) => (v === '' ? null : v),
  z.string().nullable().optional()
    .refine((v) => v == null || !Number.isNaN(Date.parse(v)), 'Deadline must be a valid date (YYYY-MM-DD)')
    .transform((v) => (v == null ? v : new Date(v)))
);

const optionalText = (max) =>
  z.string().trim().max(max, `Must be at most ${max} characters`).nullable().optional();

export const registerSchema = z.object({
  name: trimmed(2, 60, 'Name'),
  email: emailField,
  password: passwordField,
});

export const loginSchema = z.object({
  email: emailField,
  password: z.string({ required_error: 'Password is required' }).min(1, 'Password is required'),
});

export const forgotPasswordSchema = z.object({ email: emailField });

export const resetPasswordSchema = z.object({
  token: z.string().min(1, 'Reset token is required'),
  password: passwordField,
});

export const updateProfileSchema = z.object({
  name: trimmed(2, 60, 'Name').optional(),
  currentPassword: z.string().optional(),
  newPassword: passwordField.optional(),
});

const projectStatus = z.enum(['ACTIVE', 'COMPLETED', 'ARCHIVED']);
const taskStatus = z.enum(['TODO', 'IN_PROGRESS', 'DONE']);
const priority = z.enum(['LOW', 'MEDIUM', 'HIGH']);

export const createProjectSchema = z.object({
  title: trimmed(2, 120, 'Title'),
  description: optionalText(2000),
  status: projectStatus.optional(),
  deadline: deadlineField,
});
export const updateProjectSchema = createProjectSchema.partial()
  .refine((d) => Object.keys(d).length > 0, 'Send at least one field to update');

export const createTaskSchema = z.object({
  title: trimmed(2, 160, 'Title'),
  description: optionalText(2000),
  status: taskStatus.optional(),
  priority: priority.optional(),
  deadline: deadlineField,
  assignedUserId: z.string().nullable().optional().transform((v) => v || null),
});
export const updateTaskSchema = createTaskSchema.partial()
  .refine((d) => Object.keys(d).length > 0, 'Send at least one field to update');

export const projectQuerySchema = z.object({
  search: z.string().trim().optional(),
  status: projectStatus.optional(),
});

export const taskQuerySchema = z.object({
  search: z.string().trim().optional(),
  status: taskStatus.optional(),
  priority: priority.optional(),
  projectId: z.string().optional(),
  overdue: z.enum(['true', 'false']).optional(),
});
