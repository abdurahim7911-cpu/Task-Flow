import { prisma } from '../config/prisma.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const listAllUsers = asyncHandler(async (_req, res) => {
  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, createdAt: true, _count: { select: { projects: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, users: users.map(({ _count, ...u }) => ({ ...u, projectCount: _count.projects })) });
});

// Read-only overview of every project (admins can see, not modify, other users' projects).
export const listAllProjects = asyncHandler(async (_req, res) => {
  const projects = await prisma.project.findMany({
    include: { owner: { select: { id: true, name: true, email: true } }, _count: { select: { tasks: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, projects: projects.map(({ _count, ...p }) => ({ ...p, taskCount: _count.tasks })) });
});
