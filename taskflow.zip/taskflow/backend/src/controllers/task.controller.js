import { prisma } from '../config/prisma.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { getOwnedProject, getOwnedTask, assertUserExists, startOfToday } from '../utils/ownership.js';

const include = {
  assignedUser: { select: { id: true, name: true } },
  project: { select: { id: true, title: true } },
};

const buildWhere = (userId, { search, status, priority, projectId, overdue }) => ({
  project: { ownerId: userId },
  ...(projectId && { projectId }),
  ...(status && { status }),
  ...(priority && { priority }),
  ...(search && {
    OR: [
      { title: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ],
  }),
  ...(overdue === 'true' && { status: { not: 'DONE' }, deadline: { lt: startOfToday() } }),
});

// GET /api/tasks  (all of my tasks across projects, with filters)
export const listMyTasks = asyncHandler(async (req, res) => {
  const tasks = await prisma.task.findMany({
    where: buildWhere(req.user.id, req.validQuery),
    include,
    orderBy: [{ createdAt: 'desc' }],
  });
  res.json({ success: true, tasks });
});

// GET /api/projects/:id/tasks
export const listProjectTasks = asyncHandler(async (req, res) => {
  await getOwnedProject(req.params.id, req.user.id);
  const tasks = await prisma.task.findMany({
    where: buildWhere(req.user.id, { ...req.validQuery, projectId: req.params.id }),
    include,
    orderBy: [{ createdAt: 'desc' }],
  });
  res.json({ success: true, tasks });
});

// POST /api/projects/:id/tasks
export const createTask = asyncHandler(async (req, res) => {
  await getOwnedProject(req.params.id, req.user.id);
  await assertUserExists(req.body.assignedUserId);
  const task = await prisma.task.create({
    data: { ...req.body, projectId: req.params.id },
    include,
  });
  res.status(201).json({ success: true, task });
});

export const updateTask = asyncHandler(async (req, res) => {
  await getOwnedTask(req.params.id, req.user.id);
  await assertUserExists(req.body.assignedUserId);
  const task = await prisma.task.update({ where: { id: req.params.id }, data: req.body, include });
  res.json({ success: true, task });
});

export const deleteTask = asyncHandler(async (req, res) => {
  await getOwnedTask(req.params.id, req.user.id);
  await prisma.task.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Task deleted' });
});
