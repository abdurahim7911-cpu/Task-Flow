import bcrypt from 'bcryptjs';
import { prisma } from '../config/prisma.js';
import { isProd } from '../config/env.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { signToken, generateResetToken, hashToken } from '../utils/token.js';

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt });

export const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) throw ApiError.conflict('An account with this email already exists');

  const user = await prisma.user.create({
    data: { name, email, password: await bcrypt.hash(password, 12) }, // role is always USER here
  });
  res.status(201).json({ success: true, token: signToken(user), user: publicUser(user) });
});

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  // Same message for both cases so attackers can't tell which emails exist.
  if (!user || !(await bcrypt.compare(password, user.password))) {
    throw ApiError.unauthorized('Incorrect email or password');
  }
  res.json({ success: true, token: signToken(user), user: publicUser(user) });
});

export const forgotPassword = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { email: req.body.email } });
  const response = { success: true, message: 'If an account exists for this email, a reset link has been sent.' };

  if (user) {
    const { token, hash } = generateResetToken();
    await prisma.user.update({
      where: { id: user.id },
      data: { resetTokenHash: hash, resetTokenExpires: new Date(Date.now() + 60 * 60 * 1000) },
    });
    // No email service is wired up. In development the token is returned/logged so the flow can be tested.
    // In production plug an email provider in here and never return the token.
    if (!isProd) {
      console.log(`[dev] Password reset token for ${user.email}: ${token}`);
      response.devResetToken = token;
    }
  }
  res.json(response);
});

export const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  const user = await prisma.user.findFirst({
    where: { resetTokenHash: hashToken(token), resetTokenExpires: { gt: new Date() } },
  });
  if (!user) throw ApiError.badRequest('Reset token is invalid or has expired');

  await prisma.user.update({
    where: { id: user.id },
    data: { password: await bcrypt.hash(password, 12), resetTokenHash: null, resetTokenExpires: null },
  });
  res.json({ success: true, message: 'Password updated. You can now log in.' });
});
