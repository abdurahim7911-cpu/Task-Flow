import { prisma } from '../config/prisma.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { getOwnedProject } from '../utils/ownership.js';

export const listProjects = asyncHandler(async (req, res) => {
  const { search, status } = req.validQuery;
  const projects = await prisma.project.findMany({
    where: {
      ownerId: req.user.id,
      ...(status && { status }),
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
        ],
      }),
    },
    include: { _count: { select: { tasks: true } } },
    orderBy: { createdAt: 'desc' },
  });

  // Add done-count so the UI can show progress.
  const doneCounts = await prisma.task.groupBy({
    by: ['projectId'],
    where: { status: 'DONE', project: { ownerId: req.user.id } },
    _count: { _all: true },
  });
  const doneMap = Object.fromEntries(doneCounts.map((d) => [d.projectId, d._count._all]));

  res.json({
    success: true,
    projects: projects.map(({ _count, ...p }) => ({ ...p, taskCount: _count.tasks, doneCount: doneMap[p.id] || 0 })),
  });
});

export const createProject = asyncHandler(async (req, res) => {
  const project = await prisma.project.create({ data: { ...req.body, ownerId: req.user.id } });
  res.status(201).json({ success: true, project });
});

export const getProject = asyncHandler(async (req, res) => {
  const project = await getOwnedProject(req.params.id, req.user.id);
  res.json({ success: true, project });
});

export const updateProject = asyncHandler(async (req, res) => {
  await getOwnedProject(req.params.id, req.user.id);
  const project = await prisma.project.update({ where: { id: req.params.id }, data: req.body });
  res.json({ success: true, project });
});

// Business rule 1: only the owner can delete (enforced by getOwnedProject).
export const deleteProject = asyncHandler(async (req, res) => {
  await getOwnedProject(req.params.id, req.user.id);
  await prisma.project.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Project deleted' });
});
