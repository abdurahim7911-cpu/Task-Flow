import bcrypt from 'bcryptjs';
import { prisma } from '../config/prisma.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user });
});

export const updateMe = asyncHandler(async (req, res) => {
  const { name, currentPassword, newPassword } = req.body;
  const data = {};
  if (name) data.name = name;

  if (newPassword) {
    if (!currentPassword) throw ApiError.badRequest('Enter your current password to set a new one');
    const me = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!(await bcrypt.compare(currentPassword, me.password))) {
      throw ApiError.badRequest('Current password is incorrect');
    }
    data.password = await bcrypt.hash(newPassword, 12);
  }

  const user = await prisma.user.update({
    where: { id: req.user.id },
    data,
    select: { id: true, name: true, email: true, role: true, createdAt: true },
  });
  res.json({ success: true, user });
});

// Minimal list (id + name) used by the "assign to" dropdown.
export const listUsers = asyncHandler(async (_req, res) => {
  const users = await prisma.user.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } });
  res.json({ success: true, users });
});
