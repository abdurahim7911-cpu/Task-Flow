import { prisma } from '../config/prisma.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { startOfToday } from '../utils/ownership.js';

export const getStats = asyncHandler(async (req, res) => {
  const mine = { project: { ownerId: req.user.id } };
  const [totalProjects, grouped, overdue] = await Promise.all([
    prisma.project.count({ where: { ownerId: req.user.id } }),
    prisma.task.groupBy({ by: ['status'], where: mine, _count: { _all: true } }),
    prisma.task.count({ where: { ...mine, status: { not: 'DONE' }, deadline: { lt: startOfToday() } } }),
  ]);

  const byStatus = { TODO: 0, IN_PROGRESS: 0, DONE: 0 };
  grouped.forEach((g) => { byStatus[g.status] = g._count._all; });

  res.json({
    success: true,
    stats: {
      totalProjects,
      totalTasks: byStatus.TODO + byStatus.IN_PROGRESS + byStatus.DONE,
      todo: byStatus.TODO,
      inProgress: byStatus.IN_PROGRESS,
      done: byStatus.DONE,
      overdue,
    },
  });
});
