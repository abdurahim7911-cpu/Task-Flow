// Validates req.body against a zod schema and replaces it with the parsed value.
export const validate = (schema) => (req, _res, next) => {
  const result = schema.safeParse(req.body);
  if (!result.success) return next(result.error);
  req.body = result.data;
  next();
};

// Same for the query string; the parsed value is stored on req.validQuery.
export const validateQuery = (schema) => (req, _res, next) => {
  const result = schema.safeParse(req.query);
  if (!result.success) return next(result.error);
  req.validQuery = result.data;
  next();
};
