import { env } from './config/env.js';
import app from './app.js';
import { prisma } from './config/prisma.js';

const server = app.listen(env.port, () => {
  console.log(`TaskFlow API running on http://localhost:${env.port} (${env.nodeEnv})`);
});

const shutdown = async () => {
  server.close();
  await prisma.$disconnect();
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
