export const STATUS = {
  TODO: { label: 'To do', cls: 'bg-line/60 text-ink' },
  IN_PROGRESS: { label: 'In progress', cls: 'bg-amber-soft text-amber-ink' },
  DONE: { label: 'Done', cls: 'bg-pine-soft text-pine-dark' },
};
export const PROJECT_STATUS = {
  ACTIVE: { label: 'Active', cls: 'bg-pine-soft text-pine-dark' },
  COMPLETED: { label: 'Completed', cls: 'bg-line/60 text-ink' },
  ARCHIVED: { label: 'Archived', cls: 'bg-amber-soft text-amber-ink' },
};
export const PRIORITY = {
  LOW: { label: 'Low', cls: 'text-muted' },
  MEDIUM: { label: 'Medium', cls: 'text-amber-ink' },
  HIGH: { label: 'High', cls: 'text-signal' },
};

export const toDateInput = (iso) => (iso ? iso.slice(0, 10) : '');

export const formatDate = (iso) =>
  iso ? new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }) : 'No deadline';

// Matches the server rule: before today (UTC) and not done.
export const isOverdue = (deadline, status) => {
  if (!deadline || status === 'DONE') return false;
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  return new Date(deadline) < today;
};
