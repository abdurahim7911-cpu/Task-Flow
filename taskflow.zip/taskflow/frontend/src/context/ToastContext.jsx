import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  AlertCircle,
  CheckCircle2,
  X,
} from 'lucide-react';

const ToastContext = createContext(null);

export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const timersRef = useRef(new Map());

  const removeToast = useCallback((id) => {
    setToasts((current) =>
      current.filter((toast) => toast.id !== id)
    );

    const timer = timersRef.current.get(id);

    if (timer) {
      clearTimeout(timer);
      timersRef.current.delete(id);
    }
  }, []);

  const push = useCallback(
    (message, type = 'success') => {
      if (!message) return;

      const id =
        Date.now() +
        Math.random();

      setToasts((current) => [
        ...current,
        {
          id,
          message,
          type,
        },
      ]);

      const timer = setTimeout(() => {
        removeToast(id);
      }, 3500);

      timersRef.current.set(id, timer);
    },
    [removeToast]
  );

  useEffect(() => {
    const timers = timersRef.current;

    return () => {
      timers.forEach((timer) => {
        clearTimeout(timer);
      });

      timers.clear();
    };
  }, []);

  const value = {
    success: (message) =>
      push(message, 'success'),

    error: (message) =>
      push(message, 'error'),
  };

  return (
    <ToastContext.Provider value={value}>
      {children}

      <div
        className="pointer-events-none fixed inset-x-4 bottom-4 z-[60] flex flex-col items-stretch gap-3 sm:left-auto sm:right-4 sm:w-full sm:max-w-sm"
        aria-live="polite"
        aria-atomic="false"
      >
        {toasts.map((toast) => {
          const isSuccess =
            toast.type === 'success';

          return (
            <div
              key={toast.id}
              role="status"
              className={[
                'pointer-events-auto group relative overflow-hidden',
                'rounded-2xl border bg-white/95 p-4',
                'shadow-xl shadow-slate-900/10 backdrop-blur-xl',
                'animate-[toast-in_0.25s_ease-out]',
                isSuccess
                  ? 'border-emerald-200'
                  : 'border-red-200',
              ].join(' ')}
            >
              {/* TOP ACCENT */}
              <div
                aria-hidden="true"
                className={[
                  'absolute inset-x-0 top-0 h-0.5',
                  isSuccess
                    ? 'bg-emerald-500'
                    : 'bg-red-500',
                ].join(' ')}
              />

              <div className="flex items-start gap-3">
                {/* ICON */}
                <div
                  className={[
                    'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl',
                    isSuccess
                      ? 'bg-emerald-50 text-emerald-600'
                      : 'bg-red-50 text-red-600',
                  ].join(' ')}
                >
                  {isSuccess ? (
                    <CheckCircle2
                      size={19}
                      strokeWidth={2.2}
                      aria-hidden="true"
                    />
                  ) : (
                    <AlertCircle
                      size={19}
                      strokeWidth={2.2}
                      aria-hidden="true"
                    />
                  )}
                </div>

                {/* CONTENT */}
                <div className="min-w-0 flex-1 pr-5">
                  <p
                    className={[
                      'text-sm font-bold',
                      isSuccess
                        ? 'text-emerald-800'
                        : 'text-red-800',
                    ].join(' ')}
                  >
                    {isSuccess
                      ? 'Success'
                      : 'Something went wrong'}
                  </p>

                  <p className="mt-0.5 break-words text-sm leading-5 text-slate-600">
                    {toast.message}
                  </p>
                </div>

                {/* CLOSE */}
                <button
                  type="button"
                  onClick={() =>
                    removeToast(toast.id)
                  }
                  className="absolute right-3 top-3 flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  aria-label="Close notification"
                >
                  <X
                    size={15}
                    strokeWidth={2.2}
                  />
                </button>
              </div>

              {/* PROGRESS */}
              <div
                aria-hidden="true"
                className={[
                  'absolute bottom-0 left-0 h-0.5 w-full origin-left animate-[toast-progress_3.5s_linear_forwards]',
                  isSuccess
                    ? 'bg-emerald-200'
                    : 'bg-red-200',
                ].join(' ')}
              />
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}