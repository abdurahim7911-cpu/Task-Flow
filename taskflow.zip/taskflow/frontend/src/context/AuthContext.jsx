import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';

import api, {
  TOKEN_KEY,
} from '../api/client.js';

const AuthContext = createContext(null);

export const useAuth = () =>
  useContext(AuthContext);

export function AuthProvider({
  children,
}) {
  const hasToken = Boolean(
    localStorage.getItem(TOKEN_KEY)
  );

  const [user, setUser] = useState(null);
  const [loading, setLoading] =
    useState(hasToken);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setLoading(false);
  }, []);

  const authenticate = useCallback(
    async (path, body) => {
      const response = await api.post(
        path,
        body
      );

      const { token, user: authenticatedUser } =
        response.data;

      localStorage.setItem(
        TOKEN_KEY,
        token
      );

      setUser(authenticatedUser);

      return response;
    },
    []
  );

  /* ---------------------------------------------
     RESTORE AUTHENTICATED USER
     --------------------------------------------- */

  useEffect(() => {
    const token =
      localStorage.getItem(TOKEN_KEY);

    if (!token) {
      setLoading(false);
      return;
    }

    let active = true;

    api
      .get('/users/me')
      .then((response) => {
        if (!active) return;

        setUser(response.data.user);
      })
      .catch(() => {
        if (!active) return;

        localStorage.removeItem(TOKEN_KEY);
        setUser(null);
      })
      .finally(() => {
        if (!active) return;

        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  /* ---------------------------------------------
     GLOBAL LOGOUT EVENT
     --------------------------------------------- */

  useEffect(() => {
    window.addEventListener(
      'taskflow:logout',
      logout
    );

    return () => {
      window.removeEventListener(
        'taskflow:logout',
        logout
      );
    };
  }, [logout]);

  const login = useCallback(
    (body) =>
      authenticate(
        '/auth/login',
        body
      ),
    [authenticate]
  );

  const register = useCallback(
    (body) =>
      authenticate(
        '/auth/register',
        body
      ),
    [authenticate]
  );

  const value = {
    user,
    loading,
    setUser,
    logout,
    login,
    register,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}