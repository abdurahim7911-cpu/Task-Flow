import {
  Navigate,
  Outlet,
  useLocation,
} from 'react-router-dom';

import { useAuth } from '../context/AuthContext.jsx';
import Spinner from '../components/Spinner.jsx';

export default function ProtectedRoute({
  role,
}) {
  const {
    user,
    loading,
  } = useAuth();

  const location = useLocation();

  /* ---------------------------------------------
     AUTH STATE IS LOADING
     --------------------------------------------- */

  if (loading) {
    return (
      <div
        className="grid min-h-screen place-items-center bg-paper px-4"
        role="status"
        aria-live="polite"
        aria-label="Loading your account"
      >
        <div className="flex flex-col items-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-line bg-white shadow-lg shadow-slate-900/[0.06]">
            <Spinner />
          </div>

          <p className="mt-4 text-sm font-medium text-muted">
            Loading your workspace...
          </p>
        </div>
      </div>
    );
  }

  /* ---------------------------------------------
     USER IS NOT AUTHENTICATED
     --------------------------------------------- */

  if (!user) {
    return (
      <Navigate
        to="/login"
        replace
        state={{
          from: location,
        }}
      />
    );
  }

  /* ---------------------------------------------
     ROLE PROTECTION
     --------------------------------------------- */

  if (
    role &&
    user.role !== role
  ) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  /* ---------------------------------------------
     AUTHENTICATED USER
     --------------------------------------------- */

  return <Outlet />;
}