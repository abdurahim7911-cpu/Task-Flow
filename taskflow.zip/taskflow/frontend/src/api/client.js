import axios from 'axios';

export const TOKEN_KEY = 'taskflow_token';

const API_URL =
  import.meta.env.VITE_API_URL ||
  'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/* ---------------------------------------------
   REQUEST INTERCEPTOR
   Add JWT token to every authenticated request.
   --------------------------------------------- */

api.interceptors.request.use(
  (config) => {
    const token =
      localStorage.getItem(TOKEN_KEY);

    if (token) {
      config.headers = config.headers || {};
      config.headers.Authorization =
        `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

/* ---------------------------------------------
   RESPONSE INTERCEPTOR
   Handle expired / invalid JWT.
   --------------------------------------------- */

api.interceptors.response.use(
  (response) => response,

  (error) => {
    const status =
      error.response?.status;

    const requestUrl =
      error.config?.url || '';

    const isAuthCall =
      requestUrl.startsWith('/auth/');

    if (
      status === 401 &&
      !isAuthCall
    ) {
      localStorage.removeItem(
        TOKEN_KEY
      );

      window.dispatchEvent(
        new Event('taskflow:logout')
      );
    }

    return Promise.reject(error);
  }
);

/* ---------------------------------------------
   ERROR PARSER
   Converts Axios errors into a simple format
   used by Login, Register, Profile, etc.
   --------------------------------------------- */

export const parseError = (error) => {
  if (!error?.response) {
    return {
      message:
        'Cannot reach the server. Check your connection and try again.',
      fields: {},
    };
  }

  const data =
    error.response.data || {};

  const fields = {};

  if (Array.isArray(data.errors)) {
    data.errors.forEach((item) => {
      if (
        item?.field &&
        item?.message &&
        !fields[item.field]
      ) {
        fields[item.field] =
          item.message;
      }
    });
  }

  return {
    message:
      data.message ||
      'Something went wrong. Please try again.',
    fields,
  };
};

export default api;