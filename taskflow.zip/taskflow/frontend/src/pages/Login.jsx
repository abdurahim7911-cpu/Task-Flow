import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

import AuthLayout from '../components/AuthLayout.jsx';
import Field from '../components/Field.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { parseError } from '../api/client.js';

export default function Login() {
  const { user, login } = useAuth();

  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  if (user) {
    return <Navigate to="/" replace />;
  }

  const set = (key) => (event) => {
    setForm((current) => ({
      ...current,
      [key]: event.target.value,
    }));

    setErrors((current) => ({
      ...current,
      [key]: '',
    }));

    if (serverError) {
      setServerError('');
    }
  };

  const submit = async (event) => {
    event.preventDefault();

    const validation = {};

    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      validation.email = 'Enter a valid email address';
    }

    if (!form.password) {
      validation.password = 'Password is required';
    }

    setErrors(validation);

    if (Object.keys(validation).length) return;

    setBusy(true);
    setServerError('');

    try {
      await login(form);

      navigate(
        location.state?.from?.pathname || '/',
        { replace: true }
      );
    } catch (error) {
      setServerError(parseError(error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Log in to continue managing your projects and tasks."
      footer={
        <>
          Don't have an account?{' '}
          <Link
            to="/register"
            className="font-semibold text-pine underline-offset-2 transition hover:text-pine-dark hover:underline focus:outline-none focus:ring-2 focus:ring-pine/30"
          >
            Create one
          </Link>
        </>
      }
    >
      {/* TRUST FEATURES */}
      <div className="mb-6 grid grid-cols-3 gap-2.5">
        <FeatureCard
          icon={Sparkles}
          title="Simple"
          text="Easy to use"
          iconClass="bg-violet-50 text-violet-600"
        />

        <FeatureCard
          icon={ShieldCheck}
          title="Secure"
          text="Protected access"
          iconClass="bg-emerald-50 text-emerald-600"
        />

        <FeatureCard
          icon={ArrowRight}
          title="Fast"
          text="Work efficiently"
          iconClass="bg-blue-50 text-blue-600"
        />
      </div>

      {/* FORM */}
      <form onSubmit={submit} className="space-y-5" noValidate>
        <ErrorBox message={serverError} />

        <Field label="Email" error={errors.email}>
          <div className="relative">
            <Mail
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
            />

            <input
              type="email"
              autoComplete="email"
              className={`input h-11 pl-10 transition ${
                errors.email ? 'input-error' : ''
              }`}
              placeholder="you@example.com"
              value={form.email}
              onChange={set('email')}
              autoFocus
            />
          </div>
        </Field>

        <Field label="Password" error={errors.password}>
          <div className="relative">
            <LockKeyhole
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
            />

            <input
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              className={`input h-11 pl-10 pr-11 transition ${
                errors.password ? 'input-error' : ''
              }`}
              placeholder="Enter your password"
              value={form.password}
              onChange={set('password')}
            />

            <button
              type="button"
              className="absolute right-2.5 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
              onClick={() =>
                setShowPassword((value) => !value)
              }
              aria-label={
                showPassword
                  ? 'Hide password'
                  : 'Show password'
              }
            >
              {showPassword ? (
                <EyeOff size={17} />
              ) : (
                <Eye size={17} />
              )}
            </button>
          </div>
        </Field>

        {/* FORGOT PASSWORD */}
        <div className="flex items-center justify-between gap-3">
          <div className="hidden items-center gap-1.5 text-xs text-muted sm:flex">
            <CheckCircle2 size={14} className="text-emerald-500" />
            Secure account access
          </div>

          <Link
            to="/forgot-password"
            className="ml-auto rounded-md text-sm font-semibold text-pine underline-offset-2 transition hover:text-pine-dark hover:underline focus:outline-none focus:ring-2 focus:ring-pine/30"
          >
            Forgot password?
          </Link>
        </div>

        {/* SUBMIT */}
        <button
          type="submit"
          className="group relative flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl disabled:cursor-not-allowed disabled:translate-y-0 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
          disabled={busy}
        >
          <span className="relative z-10">
            {busy ? 'Logging in...' : 'Log in'}
          </span>

          {!busy && (
            <ArrowRight
              size={17}
              className="relative z-10 transition-transform duration-200 group-hover:translate-x-1"
            />
          )}
        </button>
      </form>

      {/* SECURITY NOTE */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5">
        <div className="flex items-start gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm">
            <ShieldCheck size={15} />
          </div>

          <div>
            <p className="text-xs font-bold text-slate-800">
              Your account is protected
            </p>

            <p className="mt-0.5 text-[11px] leading-5 text-muted">
              TaskFlow uses authenticated access to keep your
              projects and tasks private.
            </p>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  text,
  iconClass,
}) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md sm:p-3.5">
      <div
        className={`mx-auto flex h-9 w-9 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
      >
        <Icon size={16} />
      </div>

      <p className="mt-2 text-center text-xs font-bold text-slate-900">
        {title}
      </p>

      <p className="mt-0.5 text-center text-[10px] leading-4 text-muted">
        {text}
      </p>
    </div>
  );
}