import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
} from 'lucide-react';

import AuthLayout from '../components/AuthLayout.jsx';
import Field from '../components/Field.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { parseError } from '../api/client.js';

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  if (user) {
    return <Navigate to="/" replace />;
  }

  const set = (key) => (event) => {
    setForm((current) => ({
      ...current,
      [key]: event.target.value,
    }));

    setErrors((current) => ({
      ...current,
      [key]: '',
    }));

    if (serverError) {
      setServerError('');
    }
  };

  const submit = async (event) => {
    event.preventDefault();

    const validation = {};

    if (form.name.trim().length < 2) {
      validation.name = 'Name must be at least 2 characters';
    }

    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      validation.email = 'Enter a valid email address';
    }

    if (
      form.password.length < 8 ||
      !/[A-Za-z]/.test(form.password) ||
      !/[0-9]/.test(form.password)
    ) {
      validation.password =
        'Use at least 8 characters with a letter and a number';
    }

    setErrors(validation);

    if (Object.keys(validation).length) return;

    setBusy(true);
    setServerError('');

    try {
      await register(form);
      navigate('/', { replace: true });
    } catch (error) {
      const parsed = parseError(error);

      setErrors(parsed.fields || {});
      setServerError(parsed.message);
    } finally {
      setBusy(false);
    }
  };

  const hasLength = form.password.length >= 8;
  const hasLetter = /[A-Za-z]/.test(form.password);
  const hasNumber = /[0-9]/.test(form.password);

  const passwordScore = [
    hasLength,
    hasLetter,
    hasNumber,
  ].filter(Boolean).length;

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Set up your workspace and start planning your projects."
      footer={
        <>
          Already registered?{' '}
          <Link
            to="/login"
            className="rounded-md font-semibold text-pine underline-offset-2 transition hover:text-pine-dark hover:underline focus:outline-none focus:ring-2 focus:ring-pine/30"
          >
            Log in
          </Link>
        </>
      }
    >
      {/* TRUST FEATURES */}
      <div className="mb-6 grid grid-cols-3 gap-2.5">
        <FeatureCard
          icon={Sparkles}
          title="Simple"
          text="Easy setup"
          iconClass="bg-violet-50 text-violet-600"
        />

        <FeatureCard
          icon={ShieldCheck}
          title="Secure"
          text="Protected data"
          iconClass="bg-emerald-50 text-emerald-600"
        />

        <FeatureCard
          icon={CheckCircle2}
          title="Ready"
          text="Start quickly"
          iconClass="bg-blue-50 text-blue-600"
        />
      </div>

      {/* FORM */}
      <form onSubmit={submit} className="space-y-5" noValidate>
        <ErrorBox message={serverError} />

        {/* NAME */}
        <Field label="Name" error={errors.name}>
          <div className="relative">
            <UserRound
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
            />

            <input
              autoComplete="name"
              autoFocus
              className={`input h-11 pl-10 transition ${
                errors.name ? 'input-error' : ''
              }`}
              placeholder="Your name"
              value={form.name}
              onChange={set('name')}
            />
          </div>
        </Field>

        {/* EMAIL */}
        <Field label="Email" error={errors.email}>
          <div className="relative">
            <Mail
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
            />

            <input
              type="email"
              autoComplete="email"
              className={`input h-11 pl-10 transition ${
                errors.email ? 'input-error' : ''
              }`}
              placeholder="you@example.com"
              value={form.email}
              onChange={set('email')}
            />
          </div>
        </Field>

        {/* PASSWORD */}
        <Field
          label="Password"
          error={errors.password}
          hint="At least 8 characters, with a letter and a number."
        >
          <div className="relative">
            <LockKeyhole
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
            />

            <input
              type={showPassword ? 'text' : 'password'}
              autoComplete="new-password"
              className={`input h-11 pl-10 pr-11 transition ${
                errors.password ? 'input-error' : ''
              }`}
              placeholder="Create a strong password"
              value={form.password}
              onChange={set('password')}
            />

            <button
              type="button"
              className="absolute right-2.5 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
              onClick={() =>
                setShowPassword((value) => !value)
              }
              aria-label={
                showPassword
                  ? 'Hide password'
                  : 'Show password'
              }
            >
              {showPassword ? (
                <EyeOff size={17} />
              ) : (
                <Eye size={17} />
              )}
            </button>
          </div>
        </Field>

        {/* PASSWORD STRENGTH */}
        <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-bold text-slate-800">
              Password strength
            </p>

            <span className="text-[11px] font-semibold text-muted">
              {passwordScore === 0
                ? 'Not started'
                : passwordScore === 3
                  ? 'Strong'
                  : `${passwordScore}/3 complete`}
            </span>
          </div>

          {/* STRENGTH BAR */}
          <div className="mt-3 grid grid-cols-3 gap-1.5">
            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  passwordScore >= step
                    ? 'bg-pine'
                    : 'bg-slate-200'
                }`}
              />
            ))}
          </div>

          {/* CHECKLIST */}
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            <PasswordRule
              valid={hasLength}
              text="8+ characters"
            />

            <PasswordRule
              valid={hasLetter}
              text="One letter"
            />

            <PasswordRule
              valid={hasNumber}
              text="One number"
            />
          </div>
        </div>

        {/* SUBMIT */}
        <button
          type="submit"
          className="group relative flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl disabled:cursor-not-allowed disabled:translate-y-0 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
          disabled={busy}
        >
          <span className="relative z-10">
            {busy ? 'Creating account...' : 'Create account'}
          </span>

          {!busy && (
            <ArrowRight
              size={17}
              className="relative z-10 transition-transform duration-200 group-hover:translate-x-1"
            />
          )}
        </button>
      </form>

      {/* SECURITY NOTE */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5">
        <div className="flex items-start gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm">
            <ShieldCheck size={15} />
          </div>

          <div>
            <p className="text-xs font-bold text-slate-800">
              Your workspace starts secure
            </p>

            <p className="mt-0.5 text-[11px] leading-5 text-muted">
              Your account is protected with authenticated access
              and a secure password policy.
            </p>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  text,
  iconClass,
}) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md sm:p-3.5">
      <div
        className={`mx-auto flex h-9 w-9 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
      >
        <Icon size={16} />
      </div>

      <p className="mt-2 text-center text-xs font-bold text-slate-900">
        {title}
      </p>

      <p className="mt-0.5 text-center text-[10px] leading-4 text-muted">
        {text}
      </p>
    </div>
  );
}

function PasswordRule({ valid, text }) {
  return (
    <div
      className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${
        valid ? 'text-pine-dark' : 'text-muted'
      }`}
    >
      <span
        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full transition-all ${
          valid
            ? 'bg-emerald-100 text-emerald-600'
            : 'bg-slate-200 text-slate-400'
        }`}
      >
        <Check size={10} strokeWidth={3} />
      </span>

      <span>{text}</span>
    </div>
  );
}