
import { useState } from 'react';
import {
  CheckCircle2,
  KeyRound,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
} from 'lucide-react';

import Field from '../components/Field.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import Badge from '../components/Badge.jsx';
import api, { parseError } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';

function getInitials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

export default function Profile() {
  const { user, setUser } = useAuth();
  const toast = useToast();

  const [form, setForm] = useState({
    name: user.name,
    currentPassword: '',
    newPassword: '',
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (key) => (event) => {
    setForm((current) => ({
      ...current,
      [key]: event.target.value,
    }));

    setErrors((current) => ({
      ...current,
      [key]: '',
    }));
  };

  const submit = async (event) => {
    event.preventDefault();

    const validation = {};

    if (form.name.trim().length < 2) {
      validation.name = 'Name must be at least 2 characters';
    }

    if (form.newPassword && !form.currentPassword) {
      validation.currentPassword =
        'Enter your current password';
    }

    if (
      form.newPassword &&
      (form.newPassword.length < 8 ||
        !/[A-Za-z]/.test(form.newPassword) ||
        !/[0-9]/.test(form.newPassword))
    ) {
      validation.newPassword =
        'Use at least 8 characters with a letter and a number';
    }

    setErrors(validation);

    if (Object.keys(validation).length) return;

    const body = {
      name: form.name.trim(),
    };

    if (form.newPassword) {
      body.currentPassword = form.currentPassword;
      body.newPassword = form.newPassword;
    }

    setBusy(true);
    setServerError('');

    try {
      const response = await api.patch('/users/me', body);

      setUser(response.data.user);

      setForm((current) => ({
        ...current,
        currentPassword: '',
        newPassword: '',
      }));

      toast.success('Profile updated');
    } catch (error) {
      const parsed = parseError(error);

      setErrors(parsed.fields);
      setServerError(parsed.message);
    } finally {
      setBusy(false);
    }
  };

  const initials = getInitials(user.name);

  return (
    <div className="mx-auto max-w-6xl space-y-7 pb-12 sm:space-y-9">
      {/* HERO */}
      <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 px-5 py-7 text-white shadow-2xl sm:px-7 sm:py-8 lg:px-9 lg:py-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-28 -top-28 h-80 w-80 rounded-full bg-violet-500/20 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-36 left-1/3 h-80 w-80 rounded-full bg-blue-500/10 blur-3xl"
        />

        <div className="relative z-10 flex flex-col gap-7 md:flex-row md:items-center md:justify-between">
          <div className="flex min-w-0 items-center gap-4 sm:gap-5">
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-white/20 bg-white text-2xl font-bold text-slate-900 shadow-xl sm:h-24 sm:w-24 sm:text-3xl">
              {initials || <UserRound size={34} />}
            </div>

            <div className="min-w-0">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-xs font-semibold text-slate-200 backdrop-blur-xl">
                  <Sparkles size={13} />
                  Account settings
                </span>

                <Badge cls="bg-white/10 text-white">
                  {user.role === 'ADMIN' ? 'Admin' : 'User'}
                </Badge>
              </div>

              <h1 className="truncate text-2xl font-bold tracking-tight sm:text-3xl lg:text-4xl">
                {user.name}
              </h1>

              <p className="mt-1.5 max-w-xl text-sm leading-6 text-slate-300">
                Manage your personal information, account access,
                and security settings.
              </p>
            </div>
          </div>

          <div className="hidden shrink-0 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 backdrop-blur-xl md:block">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Account status
            </p>

            <div className="mt-2 flex items-center gap-2 text-sm font-semibold text-emerald-300">
              <CheckCircle2 size={16} />
              Active account
            </div>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT */}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px] lg:items-start">
        {/* PERSONAL INFORMATION */}
        <section className="overflow-hidden rounded-3xl border border-line bg-white shadow-sm">
          <div className="border-b border-line bg-gradient-to-r from-slate-50 via-white to-violet-50/40 px-5 py-5 sm:px-7">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
                <UserRound size={18} />
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-muted">
                  Profile
                </p>

                <h2 className="text-lg font-bold text-slate-900 sm:text-xl">
                  Personal information
                </h2>
              </div>
            </div>

            <p className="mt-3 text-sm leading-5 text-muted">
              Update your name or change your account password.
            </p>
          </div>

          <div className="p-5 sm:p-7">
            <form onSubmit={submit} className="space-y-6" noValidate>
              <ErrorBox message={serverError} />

              {/* BASIC INFORMATION */}
              <div>
                <div className="mb-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted">
                    Basic information
                  </p>
                </div>

                <div className="space-y-5">
                  <Field label="Name" error={errors.name}>
                    <div className="relative">
                      <UserRound
                        size={17}
                        aria-hidden="true"
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                      />

                      <input
                        className={`input h-11 pl-10 ${
                          errors.name ? 'input-error' : ''
                        }`}
                        value={form.name}
                        onChange={set('name')}
                        autoComplete="name"
                      />
                    </div>
                  </Field>

                  <Field label="Email">
                    <div className="relative">
                      <Mail
                        size={17}
                        aria-hidden="true"
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                      />

                      <input
                        className="input h-11 bg-slate-50 pl-10 text-slate-500"
                        value={user.email}
                        disabled
                      />
                    </div>

                    <p className="mt-1.5 text-xs text-muted">
                      Your email address is used for account access
                      and cannot be changed here.
                    </p>
                  </Field>
                </div>
              </div>

              {/* PASSWORD */}
              <div className="rounded-2xl border border-line bg-gradient-to-br from-slate-50 to-white p-4 sm:p-5">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-slate-700 shadow-sm">
                    <KeyRound size={18} />
                  </div>

                  <div className="min-w-0">
                    <h3 className="font-bold text-slate-900">
                      Change password
                    </h3>

                    <p className="mt-1 text-xs leading-5 text-muted">
                      Leave the fields empty if you do not want
                      to change your password.
                    </p>
                  </div>
                </div>

                <div className="mt-5 grid gap-5 md:grid-cols-2">
                  <Field
                    label="Current password"
                    error={errors.currentPassword}
                  >
                    <input
                      type="password"
                      autoComplete="current-password"
                      className={`input h-11 ${
                        errors.currentPassword ? 'input-error' : ''
                      }`}
                      value={form.currentPassword}
                      onChange={set('currentPassword')}
                    />
                  </Field>

                  <Field
                    label="New password"
                    error={errors.newPassword}
                    hint="At least 8 characters with a letter and a number."
                  >
                    <input
                      type="password"
                      autoComplete="new-password"
                      className={`input h-11 ${
                        errors.newPassword ? 'input-error' : ''
                      }`}
                      value={form.newPassword}
                      onChange={set('newPassword')}
                    />
                  </Field>
                </div>

                <div className="mt-5 flex flex-wrap gap-2">
                  <PasswordRule
                    active={form.newPassword.length >= 8}
                    text="8+ characters"
                  />

                  <PasswordRule
                    active={/[A-Za-z]/.test(form.newPassword)}
                    text="One letter"
                  />

                  <PasswordRule
                    active={/[0-9]/.test(form.newPassword)}
                    text="One number"
                  />
                </div>
              </div>

              {/* ACTION */}
              <div className="flex flex-col-reverse gap-3 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-xs text-muted">
                  Changes are saved securely to your account.
                </p>

                <button
                  type="submit"
                  className="btn min-h-11 min-w-36 justify-center bg-slate-900 text-white shadow-sm transition-all hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-lg focus-visible:ring-2 focus-visible:ring-slate-400 focus-visible:ring-offset-2"
                  disabled={busy}
                >
                  {busy ? 'Saving...' : 'Save changes'}
                </button>
              </div>
            </form>
          </div>
        </section>

        {/* SIDEBAR */}
        <aside className="space-y-5">
          <section className="relative overflow-hidden rounded-3xl border border-line bg-white p-5 shadow-sm sm:p-6">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-emerald-100/60 blur-3xl"
            />

            <div className="relative">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                  <ShieldCheck size={20} />
                </div>

                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted">
                    Security
                  </p>

                  <h3 className="font-bold text-slate-900">
                    Account status
                  </h3>
                </div>
              </div>

              <div className="mt-5 flex items-center gap-3 rounded-2xl border border-emerald-100 bg-emerald-50 p-3.5">
                <CheckCircle2 size={18} className="shrink-0 text-emerald-600" />

                <div>
                  <p className="text-sm font-bold text-emerald-800">
                    Active account
                  </p>

                  <p className="mt-0.5 text-xs text-emerald-700">
                    Your account is ready to use.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section className="rounded-3xl border border-line bg-white p-5 shadow-sm sm:p-6">
            <div className="mb-5">
              <p className="text-xs font-bold uppercase tracking-wider text-muted">
                Account details
              </p>

              <h3 className="mt-1 text-lg font-bold text-slate-900">
                Your access
              </h3>
            </div>

            <div className="space-y-5">
              <InfoRow label="Account email" value={user.email} icon={Mail} />

              <div className="border-t border-line pt-5">
                <InfoRow
                  label="Access level"
                  value={
                    user.role === 'ADMIN'
                      ? 'Administrator'
                      : 'Standard user'
                  }
                  icon={ShieldCheck}
                />
              </div>

              <div className="border-t border-line pt-5">
                <InfoRow
                  label="Profile"
                  value="Verified account"
                  icon={CheckCircle2}
                />
              </div>
            </div>
          </section>

          <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-violet-50 via-white to-blue-50 p-5 shadow-sm sm:p-6">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-16 -right-16 h-36 w-36 rounded-full bg-violet-200/40 blur-3xl"
            />

            <div className="relative">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm">
                <Sparkles size={18} />
              </div>

              <h3 className="mt-4 font-bold text-slate-900">
                Keep your account secure
              </h3>

              <p className="mt-1.5 text-sm leading-5 text-muted">
                Use a strong password and update it regularly to
                keep your TaskFlow account protected.
              </p>
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

function PasswordRule({ active, text }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
        active
          ? 'bg-emerald-50 text-emerald-700'
          : 'bg-slate-100 text-slate-500'
      }`}
    >
      <CheckCircle2 size={13} />
      {text}
    </span>
  );
}

function InfoRow({ label, value, icon: Icon }) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-600">
        <Icon size={16} />
      </div>

      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted">
          {label}
        </p>

        <p className="mt-1 break-all text-sm font-bold text-slate-900">
          {value}
        </p>
      </div>
    </div>
  );
}
