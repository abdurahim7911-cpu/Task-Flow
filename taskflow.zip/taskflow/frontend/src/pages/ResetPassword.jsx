import { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';

import AuthLayout from '../components/AuthLayout.jsx';
import Field from '../components/Field.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import api, { parseError } from '../api/client.js';
import { useToast } from '../context/ToastContext.jsx';

export default function ResetPassword() {
  const [params] = useSearchParams();

  const token = params.get('token') || '';

  const navigate = useNavigate();
  const toast = useToast();

  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const hasLength = password.length >= 8;
  const hasLetter = /[A-Za-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);

  const passwordScore = [
    hasLength,
    hasLetter,
    hasNumber,
  ].filter(Boolean).length;

  const submit = async (event) => {
    event.preventDefault();

    if (
      password.length < 8 ||
      !/[A-Za-z]/.test(password) ||
      !/[0-9]/.test(password)
    ) {
      setError(
        'Use at least 8 characters with a letter and a number'
      );

      return;
    }

    setBusy(true);
    setError('');

    try {
      await api.post('/auth/reset-password', {
        token,
        password,
      });

      toast.success(
        'Password updated. Log in with your new password.'
      );

      navigate('/login');
    } catch (err) {
      const parsed = parseError(err);

      setError(
        parsed.fields?.password || parsed.message
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title="Choose a new password"
      subtitle="Create a new secure password for your TaskFlow account."
      footer={
        <Link
          to="/login"
          className="inline-flex items-center gap-1.5 rounded-md font-semibold text-pine underline-offset-2 transition hover:text-pine-dark hover:underline focus:outline-none focus:ring-2 focus:ring-pine/30"
        >
          <ArrowLeft size={14} />
          Back to log in
        </Link>
      }
    >
      {!token ? (
        <InvalidTokenState />
      ) : (
        <>
          {/* TRUST FEATURES */}
          <div className="mb-6 grid grid-cols-3 gap-2.5">
            <FeatureCard
              icon={LockKeyhole}
              title="Private"
              text="Secure password"
              iconClass="bg-violet-50 text-violet-600"
            />

            <FeatureCard
              icon={ShieldCheck}
              title="Secure"
              text="Protected account"
              iconClass="bg-emerald-50 text-emerald-600"
            />

            <FeatureCard
              icon={Sparkles}
              title="Simple"
              text="Quick recovery"
              iconClass="bg-blue-50 text-blue-600"
            />
          </div>

          {/* FORM */}
          <form
            onSubmit={submit}
            className="space-y-5"
            noValidate
          >
            <ErrorBox message={error} />

            <Field
              label="New password"
              hint="At least 8 characters, with a letter and a number."
            >
              <div className="relative">
                <LockKeyhole
                  size={17}
                  className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                />

                <input
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  autoFocus
                  className={`input h-11 pl-10 pr-11 transition ${
                    error ? 'input-error' : ''
                  }`}
                  placeholder="Create a new password"
                  value={password}
                  onChange={(event) => {
                    setPassword(event.target.value);
                    setError('');
                  }}
                />

                <button
                  type="button"
                  className="absolute right-2.5 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  onClick={() =>
                    setShowPassword((value) => !value)
                  }
                  aria-label={
                    showPassword
                      ? 'Hide password'
                      : 'Show password'
                  }
                >
                  {showPassword ? (
                    <EyeOff size={17} />
                  ) : (
                    <Eye size={17} />
                  )}
                </button>
              </div>
            </Field>

            {/* PASSWORD STRENGTH */}
            <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-xs font-bold text-slate-800">
                  Password strength
                </p>

                <span className="text-[11px] font-semibold text-muted">
                  {passwordScore === 0
                    ? 'Not started'
                    : passwordScore === 3
                      ? 'Strong'
                      : `${passwordScore}/3 complete`}
                </span>
              </div>

              <div className="mt-3 grid grid-cols-3 gap-1.5">
                {[1, 2, 3].map((step) => (
                  <div
                    key={step}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      passwordScore >= step
                        ? 'bg-pine'
                        : 'bg-slate-200'
                    }`}
                  />
                ))}
              </div>

              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                <PasswordRule
                  valid={hasLength}
                  text="8+ characters"
                />

                <PasswordRule
                  valid={hasLetter}
                  text="One letter"
                />

                <PasswordRule
                  valid={hasNumber}
                  text="One number"
                />
              </div>
            </div>

            {/* SUBMIT */}
            <button
              type="submit"
              className="group relative flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl disabled:cursor-not-allowed disabled:translate-y-0 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
              disabled={busy}
            >
              <span className="relative z-10">
                {busy ? 'Saving...' : 'Save new password'}
              </span>

              {!busy && (
                <ArrowRight
                  size={17}
                  className="relative z-10 transition-transform duration-200 group-hover:translate-x-1"
                />
              )}
            </button>
          </form>

          {/* SECURITY NOTE */}
          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm">
                <ShieldCheck size={15} />
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800">
                  Your new password is private
                </p>

                <p className="mt-0.5 text-[11px] leading-5 text-muted">
                  Once saved, your previous password will no
                  longer be used to access your account.
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </AuthLayout>
  );
}

function InvalidTokenState() {
  return (
    <div className="space-y-5">
      <div className="rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50 via-white to-orange-50 p-5 shadow-sm sm:p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-amber-600 shadow-sm ring-1 ring-amber-100">
            <ShieldCheck size={23} />
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-amber-600">
              Reset link unavailable
            </p>

            <h3 className="mt-1 text-lg font-bold text-slate-900">
              This link is incomplete
            </h3>

            <p className="mt-1.5 text-sm leading-6 text-slate-600">
              Request a new password reset link from the
              Forgot password page.
            </p>
          </div>
        </div>
      </div>

      <Link
        to="/forgot-password"
        className="group flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
      >
        Request new reset link
        <ArrowRight
          size={17}
          className="transition-transform duration-200 group-hover:translate-x-1"
        />
      </Link>

      <Link
        to="/login"
        className="flex items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-slate-300 hover:bg-slate-50 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-slate-300"
      >
        <ArrowLeft size={16} />
        Return to log in
      </Link>
    </div>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  text,
  iconClass,
}) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md sm:p-3.5">
      <div
        className={`mx-auto flex h-9 w-9 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
      >
        <Icon size={16} />
      </div>

      <p className="mt-2 text-center text-xs font-bold text-slate-900">
        {title}
      </p>

      <p className="mt-0.5 text-center text-[10px] leading-4 text-muted">
        {text}
      </p>
    </div>
  );
}

function PasswordRule({ valid, text }) {
  return (
    <div
      className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${
        valid ? 'text-pine-dark' : 'text-muted'
      }`}
    >
      <span
        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full transition-all ${
          valid
            ? 'bg-emerald-100 text-emerald-600'
            : 'bg-slate-200 text-slate-400'
        }`}
      >
        <Check size={10} strokeWidth={3} />
      </span>

      <span>{text}</span>
    </div>
  );
}