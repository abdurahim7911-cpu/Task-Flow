import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Mail,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

import AuthLayout from '../components/AuthLayout.jsx';
import Field from '../components/Field.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import api, { parseError } from '../api/client.js';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError('Enter a valid email address');
      return;
    }

    setBusy(true);
    setError('');

    try {
      const response = await api.post('/auth/forgot-password', {
        email,
      });

      setResult(response.data);
    } catch (err) {
      setError(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title="Reset your password"
      subtitle="Enter your email and we will help you get back into your account."
      footer={
        <Link
          to="/login"
          className="inline-flex items-center gap-1.5 rounded-md font-semibold text-pine underline-offset-2 transition hover:text-pine-dark hover:underline focus:outline-none focus:ring-2 focus:ring-pine/30"
        >
          <ArrowLeft size={14} />
          Back to log in
        </Link>
      }
    >
      {result ? (
        <SuccessState result={result} />
      ) : (
        <>
          {/* TRUST FEATURES */}
          <div className="mb-6 grid grid-cols-3 gap-2.5">
            <FeatureCard
              icon={Mail}
              title="Email"
              text="Quick recovery"
              iconClass="bg-blue-50 text-blue-600"
            />

            <FeatureCard
              icon={ShieldCheck}
              title="Secure"
              text="Protected process"
              iconClass="bg-emerald-50 text-emerald-600"
            />

            <FeatureCard
              icon={Sparkles}
              title="Simple"
              text="Easy steps"
              iconClass="bg-violet-50 text-violet-600"
            />
          </div>

          {/* FORM */}
          <form onSubmit={submit} className="space-y-5" noValidate>
            <ErrorBox message={error} />

            <Field
              label="Email"
              hint="We'll use this email to locate your account."
            >
              <div className="relative">
                <Mail
                  size={17}
                  className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                />

                <input
                  type="email"
                  autoComplete="email"
                  autoFocus
                  className={`input h-11 pl-10 transition ${
                    error ? 'input-error' : ''
                  }`}
                  placeholder="you@example.com"
                  value={email}
                  onChange={(event) => {
                    setEmail(event.target.value);
                    setError('');
                  }}
                />
              </div>
            </Field>

            {/* SUBMIT */}
            <button
              type="submit"
              className="group relative flex min-h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl disabled:cursor-not-allowed disabled:translate-y-0 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
              disabled={busy}
            >
              <span className="relative z-10">
                {busy ? 'Sending...' : 'Send reset link'}
              </span>

              {!busy && (
                <ArrowRight
                  size={17}
                  className="relative z-10 transition-transform duration-200 group-hover:translate-x-1"
                />
              )}
            </button>
          </form>

          {/* SECURITY NOTE */}
          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm">
                <ShieldCheck size={15} />
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800">
                  Your account stays protected
                </p>

                <p className="mt-0.5 text-[11px] leading-5 text-muted">
                  Password recovery uses a temporary reset token
                  instead of exposing your current password.
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </AuthLayout>
  );
}

function SuccessState({ result }) {
  return (
    <div className="space-y-5">
      {/* SUCCESS HERO */}
      <div className="overflow-hidden rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50 via-white to-teal-50 p-5 shadow-sm sm:p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-emerald-600 shadow-sm ring-1 ring-emerald-100">
            <CheckCircle2 size={24} />
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-emerald-600">
              Recovery request sent
            </p>

            <h3 className="mt-1 text-lg font-bold text-slate-900">
              Check your email
            </h3>

            <p className="mt-1.5 text-sm leading-6 text-slate-600">
              {result.message}
            </p>
          </div>
        </div>
      </div>

      {/* DEVELOPMENT MODE */}
      {result.devResetToken && (
        <div className="rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50 to-white p-5 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-amber-600 shadow-sm">
              <Sparkles size={17} />
            </div>

            <div>
              <p className="text-sm font-bold text-slate-900">
                Development mode
              </p>

              <p className="mt-1 text-xs leading-5 text-slate-600">
                No email service is configured yet, so the
                password reset page is available directly here.
              </p>
            </div>
          </div>

          <Link
            className="group mt-4 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-md transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 sm:w-auto"
            to={`/reset-password?token=${result.devResetToken}`}
          >
            Open reset page
            <ArrowRight
              size={16}
              className="transition-transform duration-200 group-hover:translate-x-1"
            />
          </Link>
        </div>
      )}

      {/* BACK */}
      <Link
        to="/login"
        className="flex items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-slate-300 hover:bg-slate-50 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-slate-300"
      >
        <ArrowLeft size={16} />
        Return to log in
      </Link>
    </div>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  text,
  iconClass,
}) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md sm:p-3.5">
      <div
        className={`mx-auto flex h-9 w-9 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
      >
        <Icon size={16} />
      </div>

      <p className="mt-2 text-center text-xs font-bold text-slate-900">
        {title}
      </p>

      <p className="mt-0.5 text-center text-[10px] leading-4 text-muted">
        {text}
      </p>
    </div>
  );
}