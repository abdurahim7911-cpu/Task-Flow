import { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays,
  Mail,
  Search,
  ShieldCheck,
  Sparkles,
  UserRound,
  Users,
  X,
} from 'lucide-react';

import api, { parseError } from '../api/client.js';
import Spinner from '../components/Spinner.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';
import { formatDate } from '../utils/format.js';

function getInitials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');

  const load = () => {
    setLoading(true);
    setError('');

    api
      .get('/admin/users')
      .then((response) => setUsers(response.data.users))
      .catch((e) => setError(parseError(e).message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const filteredUsers = useMemo(() => {
    const query = search.trim().toLowerCase();

    return users.filter((user) => {
      const matchesSearch =
        !query ||
        user.name.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query);

      const matchesRole = !role || user.role === role;

      return matchesSearch && matchesRole;
    });
  }, [users, search, role]);

  const stats = useMemo(() => {
    const admins = users.filter(
      (user) => user.role === 'ADMIN'
    ).length;

    return {
      total: users.length,
      admins,
      members: users.length - admins,
    };
  }, [users]);

  const hasFilters = Boolean(search || role);

  return (
    <div className="space-y-7 pb-12 sm:space-y-9">
      {/* HERO */}
      <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 px-5 py-7 text-white shadow-2xl sm:px-7 sm:py-8 lg:px-9 lg:py-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-28 -top-28 h-80 w-80 rounded-full bg-violet-500/20 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-36 left-1/3 h-80 w-80 rounded-full bg-blue-500/10 blur-3xl"
        />

        <div className="relative z-10 flex flex-col gap-7 md:flex-row md:items-center md:justify-between">
          <div className="min-w-0">
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-xs font-semibold text-slate-200 backdrop-blur-xl">
                <ShieldCheck size={14} />
                Administration
              </span>

              <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300">
                {stats.total} accounts
              </span>
            </div>

            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              Users
            </h1>

            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300 sm:text-base">
              View and manage everyone using your TaskFlow
              workspace.
            </p>
          </div>

          <div className="hidden h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-white/10 backdrop-blur-xl md:flex">
            <Users size={28} />
          </div>
        </div>
      </section>

      {/* STATS */}
      <section>
        <div className="mb-4">
          <p className="text-xs font-bold uppercase tracking-wider text-muted">
            Administration overview
          </p>

          <h2 className="mt-1 text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
            Workspace users
          </h2>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <StatCard
            icon={Users}
            label="Total users"
            value={stats.total}
            description="All registered accounts"
            iconClass="bg-violet-500/10 text-violet-600"
          />

          <StatCard
            icon={ShieldCheck}
            label="Administrators"
            value={stats.admins}
            description="Accounts with admin access"
            iconClass="bg-amber-500/10 text-amber-600"
          />

          <StatCard
            icon={UserRound}
            label="Members"
            value={stats.members}
            description="Standard user accounts"
            iconClass="bg-blue-500/10 text-blue-600"
          />
        </div>
      </section>

      {/* FILTERS */}
      <section className="overflow-hidden rounded-3xl border border-line bg-white shadow-sm">
        <div className="border-b border-line bg-gradient-to-r from-slate-50 via-white to-violet-50/40 px-5 py-5 sm:px-6">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
                  <Search size={18} />
                </div>

                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted">
                    Directory
                  </p>

                  <h2 className="text-lg font-bold text-slate-900">
                    Find users
                  </h2>
                </div>
              </div>

              <p className="mt-2 text-sm text-muted">
                Search by name or email and filter by account role.
              </p>
            </div>

            <div className="grid gap-2.5 sm:grid-cols-[minmax(0,1fr)_auto] xl:min-w-[620px]">
              <div className="relative min-w-0">
                <Search
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                />

                <input
                  className="input h-11 w-full border-slate-200 bg-white pl-10 pr-10 shadow-sm"
                  placeholder="Search by name or email..."
                  value={search}
                  onChange={(event) =>
                    setSearch(event.target.value)
                  }
                  aria-label="Search users"
                />

                {search && (
                  <button
                    type="button"
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                    aria-label="Clear search"
                  >
                    <X size={15} />
                  </button>
                )}
              </div>

              <select
                className="input h-11 w-full border-slate-200 bg-white shadow-sm sm:w-auto"
                value={role}
                onChange={(event) =>
                  setRole(event.target.value)
                }
                aria-label="Filter by role"
              >
                <option value="">All roles</option>
                <option value="ADMIN">Administrators</option>
                <option value="USER">Users</option>
              </select>
            </div>
          </div>

          {hasFilters && (
            <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-line pt-4">
              <span className="text-xs font-semibold text-muted">
                Active filters:
              </span>

              {search && (
                <button
                  type="button"
                  className="inline-flex max-w-full items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  onClick={() => setSearch('')}
                >
                  <span className="max-w-52 truncate">
                    Search: {search}
                  </span>
                  <X size={12} />
                </button>
              )}

              {role && (
                <button
                  type="button"
                  className="inline-flex items-center gap-1 rounded-full bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-700 transition hover:bg-violet-100 focus:outline-none focus:ring-2 focus:ring-violet-200"
                  onClick={() => setRole('')}
                >
                  Role:{' '}
                  {role === 'ADMIN'
                    ? 'Administrator'
                    : 'User'}
                  <X size={12} />
                </button>
              )}

              <span className="text-xs text-muted">
                Showing {filteredUsers.length} of {users.length}
              </span>

              <button
                type="button"
                className="rounded-md px-2 py-1 text-xs font-semibold text-muted transition hover:bg-slate-100 hover:text-slate-900 hover:underline focus:outline-none focus:ring-2 focus:ring-slate-300"
                onClick={() => {
                  setSearch('');
                  setRole('');
                }}
              >
                Clear all
              </button>
            </div>
          )}
        </div>
      </section>

      {/* USERS */}
      <section>
        {loading ? (
          <div className="rounded-3xl border border-line bg-white p-10 shadow-sm">
            <Spinner label="Loading users" />
          </div>
        ) : error ? (
          <ErrorBox message={error} onRetry={load} />
        ) : filteredUsers.length === 0 ? (
          <div className="rounded-3xl border border-line bg-white p-6 shadow-sm sm:p-10">
            <EmptyState
              icon={Users}
              title={
                hasFilters
                  ? 'No users found'
                  : 'No users yet'
              }
              text={
                hasFilters
                  ? 'Try changing your search or filters.'
                  : 'Registered users will appear here.'
              }
            />
          </div>
        ) : (
          <>
            {/* DESKTOP TABLE */}
            <div className="hidden overflow-hidden rounded-3xl border border-line bg-white shadow-sm md:block">
              <div className="border-b border-line bg-gradient-to-r from-slate-50 to-white px-5 py-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-muted">
                      User directory
                    </p>

                    <h2 className="mt-1 font-bold text-slate-900">
                      {filteredUsers.length}{' '}
                      {filteredUsers.length === 1
                        ? 'user'
                        : 'users'}
                    </h2>
                  </div>

                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-600">
                    <Users size={17} />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] text-left text-sm">
                  <thead className="border-b border-line bg-slate-50/80">
                    <tr>
                      <th className="px-5 py-4 font-semibold text-muted">
                        User
                      </th>

                      <th className="px-5 py-4 font-semibold text-muted">
                        Role
                      </th>

                      <th className="px-5 py-4 font-semibold text-muted">
                        Projects
                      </th>

                      <th className="px-5 py-4 font-semibold text-muted">
                        Joined
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr
                        key={user.id}
                        className="border-b border-line last:border-0 transition-colors hover:bg-slate-50/70"
                      >
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <UserAvatar user={user} />

                            <div className="min-w-0">
                              <p className="truncate font-bold text-slate-900">
                                {user.name}
                              </p>

                              <p className="mt-1 flex items-center gap-1 truncate text-xs text-muted">
                                <Mail size={12} />
                                {user.email}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="px-5 py-4">
                          <RoleBadge role={user.role} />
                        </td>

                        <td className="px-5 py-4">
                          <span className="inline-flex min-w-9 items-center justify-center rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs font-bold text-slate-700">
                            {user.projectCount}
                          </span>
                        </td>

                        <td className="px-5 py-4 text-muted">
                          <span className="inline-flex items-center gap-2 text-xs font-semibold">
                            <CalendarDays size={14} />
                            {formatDate(user.createdAt)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* MOBILE */}
            <div className="grid gap-3 md:hidden">
              {filteredUsers.map((user) => (
                <article
                  key={user.id}
                  className="group relative overflow-hidden rounded-3xl border border-line bg-white p-4 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-xl"
                >
                  <div
                    className={`absolute inset-x-0 top-0 h-1 ${
                      user.role === 'ADMIN'
                        ? 'bg-gradient-to-r from-amber-400 to-orange-400'
                        : 'bg-gradient-to-r from-blue-500 to-cyan-400'
                    }`}
                  />

                  <div className="flex items-start gap-3 pt-1">
                    <UserAvatar user={user} />

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h2 className="truncate font-bold text-slate-900">
                            {user.name}
                          </h2>

                          <p className="mt-1 flex items-start gap-1 break-all text-xs leading-5 text-muted">
                            <Mail
                              size={12}
                              className="mt-0.5 shrink-0"
                            />
                            {user.email}
                          </p>
                        </div>

                        <RoleBadge role={user.role} />
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid grid-cols-2 gap-3 border-t border-line pt-4">
                    <div className="rounded-xl bg-slate-50 p-3">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-muted">
                        Projects
                      </p>

                      <p className="mt-1 text-lg font-bold text-slate-900">
                        {user.projectCount}
                      </p>
                    </div>

                    <div className="rounded-xl bg-slate-50 p-3">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-muted">
                        Joined
                      </p>

                      <p className="mt-1 flex items-center gap-1 text-xs font-bold text-slate-900">
                        <CalendarDays size={13} />
                        {formatDate(user.createdAt)}
                      </p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}
      </section>

      {/* BOTTOM INSIGHT */}
      {!loading && !error && users.length > 0 && (
        <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-r from-violet-50 via-white to-blue-50 p-5 shadow-sm sm:p-6">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-violet-200/30 blur-3xl"
          />

          <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm">
                <Sparkles size={19} />
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-violet-600">
                  Admin insight
                </p>

                <h3 className="mt-1 font-bold text-slate-900">
                  Workspace directory is up to date
                </h3>

                <p className="mt-1 max-w-2xl text-sm leading-5 text-muted">
                  {stats.total} accounts are registered, including{' '}
                  {stats.admins}{' '}
                  {stats.admins === 1
                    ? 'administrator'
                    : 'administrators'}{' '}
                  and {stats.members}{' '}
                  {stats.members === 1
                    ? 'member'
                    : 'members'}.
                </p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-2 rounded-xl border border-white bg-white/80 px-4 py-3 shadow-sm">
              <ShieldCheck
                size={16}
                className="text-emerald-600"
              />

              <span className="text-xs font-bold text-slate-700">
                Admin access
              </span>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  description,
  iconClass,
}) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-4 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-xl sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <span className="text-[11px] font-bold uppercase tracking-wider text-muted">
          {label}
        </span>

        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
        >
          <Icon size={18} />
        </div>
      </div>

      <p className="mt-4 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
        {value}
      </p>

      <p className="mt-1 text-xs font-medium leading-5 text-muted">
        {description}
      </p>
    </div>
  );
}

function UserAvatar({ user }) {
  return (
    <div
      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xs font-bold shadow-sm ${
        user.role === 'ADMIN'
          ? 'bg-gradient-to-br from-amber-100 to-orange-50 text-amber-700'
          : 'bg-gradient-to-br from-slate-100 to-blue-50 text-slate-700'
      }`}
    >
      {getInitials(user.name) || <UserRound size={16} />}
    </div>
  );
}

function RoleBadge({ role }) {
  return (
    <Badge
      cls={
        role === 'ADMIN'
          ? 'bg-amber-soft text-amber-ink'
          : 'bg-slate-100 text-slate-700'
      }
    >
      {role === 'ADMIN' ? 'Admin' : 'User'}
    </Badge>
  );
}