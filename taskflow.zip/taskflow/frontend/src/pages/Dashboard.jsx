
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  CircleDashed,
  Clock3,
  FolderKanban,
  ListChecks,
  Plus,
  Search,
  Sparkles,
  Target,
  TrendingUp,
  X,
  Zap,
} from 'lucide-react';

import api, { parseError } from '../api/client.js';
import Spinner from '../components/Spinner.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { STATUS, PRIORITY, formatDate, isOverdue } from '../utils/format.js';

const CARDS = [
  {
    key: 'totalProjects',
    label: 'Total projects',
    icon: FolderKanban,
    accent: 'from-violet-500/15 to-violet-500/5',
    iconBg: 'bg-violet-500/10 text-violet-600',
  },
  {
    key: 'totalTasks',
    label: 'Total tasks',
    icon: ListChecks,
    accent: 'from-blue-500/15 to-blue-500/5',
    iconBg: 'bg-blue-500/10 text-blue-600',
  },
  {
    key: 'todo',
    label: 'To do',
    icon: CircleDashed,
    accent: 'from-amber-500/15 to-amber-500/5',
    iconBg: 'bg-amber-500/10 text-amber-600',
  },
  {
    key: 'inProgress',
    label: 'In progress',
    icon: Activity,
    accent: 'from-cyan-500/15 to-cyan-500/5',
    iconBg: 'bg-cyan-500/10 text-cyan-600',
  },
  {
    key: 'done',
    label: 'Completed',
    icon: CheckCircle2,
    accent: 'from-emerald-500/15 to-emerald-500/5',
    iconBg: 'bg-emerald-500/10 text-emerald-600',
  },
  {
    key: 'overdue',
    label: 'Overdue',
    icon: Clock3,
    accent: 'from-rose-500/15 to-rose-500/5',
    iconBg: 'bg-rose-500/10 text-rose-600',
    danger: true,
  },
];

const STATUS_FILTERS = [
  { value: '', label: 'All status' },
  { value: 'TODO', label: 'To do' },
  { value: 'IN_PROGRESS', label: 'In progress' },
  { value: 'DONE', label: 'Completed' },
];

const PRIORITY_FILTERS = [
  { value: '', label: 'All priority' },
  { value: 'HIGH', label: 'High' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'LOW', label: 'Low' },
];

function getInitials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

function getGreeting() {
  const hour = new Date().getHours();

  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function getCompletionPercent(stats) {
  if (!stats?.totalTasks) return 0;
  return Math.round((stats.done / stats.totalTasks) * 100);
}

function getStatusDot(status) {
  if (status === 'DONE') return 'bg-emerald-500';
  if (status === 'IN_PROGRESS') return 'bg-cyan-500';
  return 'bg-amber-500';
}

export default function Dashboard() {
  const { user } = useAuth();

  const [stats, setStats] = useState(null);
  const [statsError, setStatsError] = useState('');
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);

  const [filters, setFilters] = useState({
    search: '',
    status: '',
    priority: '',
    projectId: '',
    overdue: false,
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadStats = useCallback(() => {
    setStatsError('');

    api
      .get('/dashboard/stats')
      .then((response) => {
        setStats(response.data.stats);
      })
      .catch((err) => {
        setStatsError(parseError(err).message);
      });
  }, []);

  useEffect(() => {
    loadStats();

    api
      .get('/projects')
      .then((response) => {
        setProjects(response.data.projects);
      })
      .catch(() => { });
  }, [loadStats]);

  const loadTasks = useCallback(() => {
    setLoading(true);
    setError('');

    const params = {};

    if (filters.search) params.search = filters.search;
    if (filters.status) params.status = filters.status;
    if (filters.priority) params.priority = filters.priority;
    if (filters.projectId) params.projectId = filters.projectId;
    if (filters.overdue) params.overdue = 'true';

    api
      .get('/tasks', { params })
      .then((response) => {
        setTasks(response.data.tasks);
      })
      .catch((err) => {
        setError(parseError(err).message);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [filters]);

  useEffect(() => {
    const timer = setTimeout(loadTasks, 250);
    return () => clearTimeout(timer);
  }, [loadTasks]);

  const setFilter = (key) => (event) => {
    const value =
      event.target.type === 'checkbox'
        ? event.target.checked
        : event.target.value;

    setFilters((current) => ({
      ...current,
      [key]: value,
    }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      status: '',
      priority: '',
      projectId: '',
      overdue: false,
    });
  };

  const hasFilters =
    filters.search ||
    filters.status ||
    filters.priority ||
    filters.projectId ||
    filters.overdue;

  const completionPercent = useMemo(
    () => getCompletionPercent(stats),
    [stats]
  );

  const activeTasks = useMemo(
    () =>
      tasks.filter(
        (task) => task.status === 'TODO' || task.status === 'IN_PROGRESS'
      ).length,
    [tasks]
  );

  const overdueTasks = useMemo(
    () =>
      tasks.filter((task) => isOverdue(task.deadline, task.status)).length,
    [tasks]
  );

  const firstName = user?.name?.split(' ')[0] || 'there';
  const initials = getInitials(user?.name);

  return (
    <div className="space-y-6 pb-10 sm:space-y-8">
      {/* HERO */}
      <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 px-5 py-6 text-white shadow-xl sm:px-7 sm:py-8 lg:px-8 lg:py-9">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-violet-500/20 blur-3xl"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-blue-500/10 blur-3xl"
        />

        <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between lg:gap-8">
          <div className="max-w-2xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-xs font-medium text-slate-200 backdrop-blur">
              <Sparkles size={14} />
              Your workspace overview
            </div>

            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
              {getGreeting()}, {firstName}
            </h1>

            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300 sm:text-base">
              Keep your projects moving, stay ahead of deadlines, and see
              everything important from one place.
            </p>

            {/* ACTION BUTTONS */}
            <div className="mt-5 flex flex-col gap-2.5 sm:flex-row">
              <Link
                to="/projects"
                className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm transition-colors duration-200 hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 sm:w-auto"
              >
                <FolderKanban size={17} aria-hidden="true" />
                View projects
                <ArrowUpRight size={15} aria-hidden="true" />
              </Link>

              <Link
                to="/projects"
                className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white shadow-sm backdrop-blur transition-colors duration-200 hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70 sm:w-auto"
              >
                <Plus size={17} aria-hidden="true" />
                New project
              </Link>
            </div>
          </div>

          <div className="flex min-w-0 items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur sm:max-w-sm lg:min-w-[270px]">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-sm font-bold">
              {initials || 'U'}
            </div>

            <div className="min-w-0">
              <p className="truncate font-semibold">{user?.name || 'User'}</p>
              <p className="mt-1 truncate text-xs text-slate-400">
                {user?.email || 'Workspace member'}
              </p>

              <div className="mt-3 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                <span className="text-xs text-slate-300">
                  Active workspace
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section aria-label="Workspace statistics">
        {statsError ? (
          <ErrorBox message={statsError} onRetry={loadStats} />
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 xl:grid-cols-6">
            {CARDS.map((card) => {
              const Icon = card.icon;
              const value = stats ? stats[card.key] : null;
              const isDanger = card.danger && stats?.overdue > 0;

              return (
                <div
                  key={card.key}
                  className={`group relative overflow-hidden rounded-2xl border border-line bg-gradient-to-br ${card.accent} bg-white p-4 shadow-sm transition duration-200 hover:-translate-y-1 hover:shadow-lg ${isDanger ? 'border-rose-200 ring-1 ring-rose-100' : ''
                    }`}
                >
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-xl ${card.iconBg}`}
                  >
                    <Icon size={19} />
                  </div>

                  <div className="mt-4">
                    <div
                      className={`text-2xl font-bold tracking-tight ${isDanger ? 'text-rose-600' : 'text-slate-900'
                        }`}
                    >
                      {value ?? '—'}
                    </div>
                    <p className="mt-1 text-xs font-medium leading-5 text-muted">
                      {card.label}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* PRODUCTIVITY */}
      <section className="grid gap-5 lg:grid-cols-[1.4fr_0.6fr]">
        <div className="rounded-2xl border border-line bg-white p-5 shadow-sm sm:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-violet-500/10 text-violet-600">
                  <TrendingUp size={18} />
                </div>
                <h2 className="font-bold text-slate-900">
                  Productivity overview
                </h2>
              </div>

              <p className="mt-2 text-sm text-muted">
                Your current task completion progress.
              </p>
            </div>

            <div className="sm:text-right">
              <div className="text-3xl font-bold text-slate-900">
                {completionPercent}%
              </div>
              <div className="text-xs text-muted">completed</div>
            </div>
          </div>

          <div className="mt-6">
            <div
              className="h-3 overflow-hidden rounded-full bg-slate-100"
              aria-label={`Task completion ${completionPercent}%`}
              role="progressbar"
              aria-valuenow={completionPercent}
              aria-valuemin="0"
              aria-valuemax="100"
            >
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 via-blue-500 to-cyan-400 transition-all duration-700"
                style={{ width: `${completionPercent}%` }}
              />
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2 sm:gap-3">
              {[
                {
                  label: 'To do',
                  value: stats?.todo,
                  dot: 'bg-amber-400',
                },
                {
                  label: 'Active',
                  value: stats?.inProgress,
                  dot: 'bg-cyan-400',
                },
                {
                  label: 'Done',
                  value: stats?.done,
                  dot: 'bg-emerald-400',
                },
              ].map((item) => (
                <div key={item.label} className="rounded-xl bg-slate-50 p-3">
                  <div className="flex items-center gap-2 text-xs text-muted">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${item.dot}`} />
                    {item.label}
                  </div>
                  <div className="mt-1 text-lg font-bold">
                    {item.value ?? '—'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-white p-5 shadow-sm sm:p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 text-blue-600">
              <Target size={18} />
            </div>
            <h2 className="font-bold text-slate-900">Today at a glance</h2>
          </div>

          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-500/10 text-blue-600">
                  <ListChecks size={17} />
                </div>
                <span className="truncate text-sm font-medium">Active tasks</span>
              </div>
              <span className="font-bold">{activeTasks}</span>
            </div>

            <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-rose-500/10 text-rose-600">
                  <Clock3 size={17} />
                </div>
                <span className="truncate text-sm font-medium">Overdue</span>
              </div>
              <span className="font-bold text-rose-600">
                {stats?.overdue ?? overdueTasks}
              </span>
            </div>

            <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-violet-500/10 text-violet-600">
                  <FolderKanban size={17} />
                </div>
                <span className="truncate text-sm font-medium">Projects</span>
              </div>
              <span className="font-bold">{stats?.totalProjects ?? '—'}</span>
            </div>
          </div>
        </div>
      </section>

      {/* TASKS */}
      <section aria-label="Tasks">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-white">
                <Zap size={18} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">All tasks</h2>
                <p className="text-sm text-muted">
                  Search, filter and manage your work.
                </p>
              </div>
            </div>
          </div>

          <Link
            to="/projects"
            className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-2.5 text-sm font-semibold shadow-sm transition-colors duration-200 hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 sm:w-auto"
          >
            <FolderKanban size={16} />
            Browse projects
            <ArrowUpRight size={15} />
          </Link>
        </div>

        {/* FILTERS */}
        <div className="mt-5 rounded-2xl border border-line bg-white p-4 shadow-sm sm:p-5">
          <div className="grid gap-3 lg:grid-cols-[2fr_1fr_1fr_1.2fr_auto] lg:items-center">
            <div className="relative">
              <Search
                size={17}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
              />
              <input
                className="input h-11 w-full pl-10 pr-10"
                placeholder="Search tasks..."
                aria-label="Search tasks"
                value={filters.search}
                onChange={setFilter('search')}
              />

              {filters.search && (
                <button
                  type="button"
                  onClick={() =>
                    setFilters((current) => ({ ...current, search: '' }))
                  }
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  aria-label="Clear search"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            <select
              className="input h-11"
              aria-label="Filter by status"
              value={filters.status}
              onChange={setFilter('status')}
            >
              {STATUS_FILTERS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            <select
              className="input h-11"
              aria-label="Filter by priority"
              value={filters.priority}
              onChange={setFilter('priority')}
            >
              {PRIORITY_FILTERS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            <select
              className="input h-11"
              aria-label="Filter by project"
              value={filters.projectId}
              onChange={setFilter('projectId')}
            >
              <option value="">All projects</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </select>

            <label className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-line bg-slate-50 px-3 text-sm font-medium transition hover:bg-slate-100">
              <input
                type="checkbox"
                checked={filters.overdue}
                onChange={setFilter('overdue')}
                className="h-4 w-4 accent-pine"
              />
              Overdue
            </label>
          </div>

          {hasFilters && (
            <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-4">
              <span className="text-xs font-medium text-muted">Active filters:</span>

              {filters.search && (
                <span className="max-w-full truncate rounded-full bg-slate-100 px-3 py-1 text-xs font-medium">
                  Search: {filters.search}
                </span>
              )}
              {filters.status && (
                <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700">
                  {STATUS[filters.status]?.label || filters.status}
                </span>
              )}
              {filters.priority && (
                <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-700">
                  {PRIORITY[filters.priority]?.label || filters.priority}
                </span>
              )}
              {filters.projectId && (
                <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-medium text-violet-700">
                  Project selected
                </span>
              )}
              {filters.overdue && (
                <span className="rounded-full bg-rose-50 px-3 py-1 text-xs font-medium text-rose-700">
                  Overdue only
                </span>
              )}

              <button
                type="button"
                onClick={clearFilters}
                className="ml-auto rounded-md px-2 py-1 text-xs font-semibold text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
              >
                Clear all
              </button>
            </div>
          )}
        </div>

        {/* TASK LIST */}
        <div className="mt-5">
          {loading ? (
            <div className="rounded-2xl border border-line bg-white p-10 shadow-sm">
              <Spinner label="Loading tasks" />
            </div>
          ) : error ? (
            <ErrorBox message={error} onRetry={loadTasks} />
          ) : tasks.length === 0 ? (
            <div className="rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
              <EmptyState
                icon={ListChecks}
                title={hasFilters ? 'No tasks match these filters' : 'No tasks yet'}
                text={
                  hasFilters
                    ? 'Try clearing a filter or searching for something else.'
                    : 'Open a project and add your first task.'
                }
                action={
                  !hasFilters && (

                    <Link
                      to="/projects"
                      className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
                    >
                      Go to projects
                      <ArrowUpRight size={16} />
                    </Link>

                  )
                }
              />
            </div>
          ) : (
            <>
              {/* Desktop */}
              <div className="hidden overflow-hidden rounded-2xl border border-line bg-white shadow-sm md:block">
                <div className="grid grid-cols-[minmax(0,1fr)_130px_120px_120px_40px] items-center gap-4 border-b border-line bg-slate-50/80 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-muted">
                  <span>Task</span>
                  <span>Priority</span>
                  <span>Deadline</span>
                  <span>Status</span>
                  <span />
                </div>

                <ul className="divide-y divide-line">
                  {tasks.map((task) => {
                    const late = isOverdue(task.deadline, task.status);

                    return (
                      <li
                        key={task.id}
                        className="group px-5 py-4 transition hover:bg-slate-50/80"
                      >
                        <div className="grid grid-cols-[minmax(0,1fr)_130px_120px_120px_40px] items-center gap-4">
                          <div className="min-w-0">
                            <div className="flex items-start gap-3">
                              <span
                                className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${getStatusDot(task.status)}`}
                              />
                              <div className="min-w-0">
                                <Link
                                  to={`/projects/${task.project.id}`}
                                  className="block truncate font-semibold text-slate-900 transition hover:text-pine hover:underline"
                                >
                                  {task.title}
                                </Link>

                                <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted">
                                  <span>{task.project.title}</span>
                                  {task.assignedUser && (
                                    <>
                                      <span>•</span>
                                      <span>{task.assignedUser.name}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>

                          <div>
                            <span
                              className={`text-xs font-bold ${PRIORITY[task.priority]?.cls || ''}`}
                            >
                              {PRIORITY[task.priority]?.label || task.priority}
                            </span>
                          </div>

                          <div className={`flex items-center gap-1.5 text-xs ${late ? 'font-bold text-rose-600' : 'text-muted'}`}>
                            <CalendarDays size={14} />
                            <span>
                              {late ? 'Overdue • ' : ''}
                              {formatDate(task.deadline)}
                            </span>
                          </div>

                          <div>
                            <Badge cls={STATUS[task.status]?.cls}>
                              {STATUS[task.status]?.label || task.status}
                            </Badge>
                          </div>

                          <Link
                            to={`/projects/${task.project.id}`}
                            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted opacity-60 transition hover:bg-slate-100 hover:text-slate-900 hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-slate-300"
                            aria-label={`Open ${task.title}`}
                          >
                            <ArrowUpRight size={16} />
                          </Link>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>

              {/* Mobile */}
              <div className="space-y-3 md:hidden">
                {tasks.map((task) => {
                  const late = isOverdue(task.deadline, task.status);

                  return (
                    <article
                      key={task.id}
                      className="rounded-2xl border border-line bg-white p-4 shadow-sm transition hover:shadow-md"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-start gap-3">
                          <span
                            className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${getStatusDot(task.status)}`}
                          />
                          <div className="min-w-0">
                            <Link
                              to={`/projects/${task.project.id}`}
                              className="block break-words font-semibold text-slate-900 hover:text-pine"
                            >
                              {task.title}
                            </Link>
                            <p className="mt-1 truncate text-xs text-muted">
                              {task.project.title}
                            </p>
                          </div>
                        </div>

                        <Link
                          to={`/projects/${task.project.id}`}
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                          aria-label={`Open ${task.title}`}
                        >
                          <ArrowUpRight size={16} />
                        </Link>
                      </div>

                      <div className="mt-4 flex flex-wrap items-center gap-2">
                        <Badge cls={STATUS[task.status]?.cls}>
                          {STATUS[task.status]?.label || task.status}
                        </Badge>
                        <span
                          className={`rounded-full bg-slate-50 px-2.5 py-1 text-xs font-semibold ${PRIORITY[task.priority]?.cls || ''}`}
                        >
                          {PRIORITY[task.priority]?.label || task.priority}
                        </span>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-2 border-t border-line pt-3">
                        <div>
                          <p className="text-[11px] font-medium uppercase tracking-wide text-muted">
                            Deadline
                          </p>
                          <div className={`mt-1 flex items-center gap-1.5 text-xs ${late ? 'font-bold text-rose-600' : 'text-slate-700'}`}>
                            <CalendarDays size={13} />
                            <span>
                              {late ? 'Overdue • ' : ''}
                              {formatDate(task.deadline)}
                            </span>
                          </div>
                        </div>

                        <div>
                          <p className="text-[11px] font-medium uppercase tracking-wide text-muted">
                            Assigned
                          </p>
                          <p className="mt-1 truncate text-xs font-medium text-slate-700">
                            {task.assignedUser?.name || 'Unassigned'}
                          </p>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </section>

      {/* PROJECTS */}
      {projects.length > 0 && (
        <section>
          <div className="flex items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-500/10 text-violet-600">
                  <FolderKanban size={18} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">Your projects</h2>
                  <p className="text-sm text-muted">
                    Quickly jump back into your workspace.
                  </p>
                </div>
              </div>
            </div>

            <Link
              to="/projects"
              className="hidden rounded-md px-2 py-1 text-sm font-semibold text-pine transition hover:bg-slate-50 hover:underline sm:block"
            >
              View all
            </Link>
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {projects.slice(0, 4).map((project) => (
              <Link
                key={project.id}
                to={`/projects/${project.id}`}
                className="group rounded-2xl border border-line bg-white p-5 shadow-sm transition duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-slate-300"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-white">
                    <FolderKanban size={19} />
                  </div>
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition group-hover:bg-slate-100 group-hover:text-slate-900">
                    <ArrowUpRight size={16} />
                  </div>
                </div>

                <h3 className="mt-5 truncate font-bold text-slate-900">
                  {project.title}
                </h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted">
                  {project.description || 'No project description'}
                </p>

                <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
                  <span className="text-xs font-medium text-muted">Open project</span>
                  <span className="text-xs font-semibold text-pine">Explore →</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
