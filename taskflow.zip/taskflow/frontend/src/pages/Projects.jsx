
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Archive,
  CalendarDays,
  CheckCircle2,
  Clock3,
  FolderKanban,
  Layers3,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';

import api, { parseError } from '../api/client.js';
import Spinner from '../components/Spinner.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';
import ProjectForm from '../components/ProjectForm.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { PROJECT_STATUS, formatDate } from '../utils/format.js';

const STATUS_OPTIONS = [
  { value: '', label: 'All statuses' },
  { value: 'ACTIVE', label: 'Active' },
  { value: 'COMPLETED', label: 'Completed' },
  { value: 'ARCHIVED', label: 'Archived' },
];

function getProjectIcon(status) {
  if (status === 'COMPLETED') return CheckCircle2;
  if (status === 'ARCHIVED') return Archive;
  return Layers3;
}

function getProjectAccent(status) {
  if (status === 'COMPLETED') {
    return {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-600',
      line: 'from-emerald-500 to-cyan-400',
    };
  }

  if (status === 'ARCHIVED') {
    return {
      bg: 'bg-slate-500/10',
      text: 'text-slate-600',
      line: 'from-slate-400 to-slate-500',
    };
  }

  return {
    bg: 'bg-violet-500/10',
    text: 'text-violet-600',
    line: 'from-violet-500 to-blue-500',
  };
}

export default function Projects() {
  const toast = useToast();

  const [projects, setProjects] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');

    const params = {};

    if (search) params.search = search;
    if (status) params.status = status;

    api
      .get('/projects', { params })
      .then((response) => {
        setProjects(response.data.projects);
      })
      .catch((err) => {
        setError(parseError(err).message);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [search, status]);

  useEffect(() => {
    const timer = setTimeout(load, 250);
    return () => clearTimeout(timer);
  }, [load]);

  const remove = async () => {
    if (!deleting || busy) return;

    setBusy(true);

    try {
      await api.delete(`/projects/${deleting.id}`);

      toast.success('Project deleted');
      setDeleting(null);
      load();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const clearFilters = () => {
    setSearch('');
    setStatus('');
  };

  const hasFilters = Boolean(search || status);

  const summary = useMemo(() => {
    const total = projects.length;

    const active = projects.filter(
      (project) => project.status === 'ACTIVE'
    ).length;

    const completed = projects.filter(
      (project) => project.status === 'COMPLETED'
    ).length;

    const archived = projects.filter(
      (project) => project.status === 'ARCHIVED'
    ).length;

    const totalTasks = projects.reduce(
      (sum, project) => sum + (project.taskCount || 0),
      0
    );

    const completedTasks = projects.reduce(
      (sum, project) => sum + (project.doneCount || 0),
      0
    );

    const overallProgress = totalTasks
      ? Math.round((completedTasks / totalTasks) * 100)
      : 0;

    return {
      total,
      active,
      completed,
      archived,
      totalTasks,
      completedTasks,
      overallProgress,
    };
  }, [projects]);

  return (
    <div className="space-y-6 pb-10 sm:space-y-8">
      {/* HERO */}
      <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 px-5 py-6 text-white shadow-xl sm:px-7 sm:py-8 md:px-8 md:py-9">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-violet-500/20 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-blue-500/10 blur-3xl"
        />

        <div className="relative z-10 flex flex-col gap-7 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-xs font-medium text-slate-200 backdrop-blur">
              <Sparkles size={14} />
              Project workspace
            </div>

            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
              Your projects
            </h1>

            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300 sm:text-base">
              Organize your work, track progress, and keep every project
              moving toward completion.
            </p>

            {/* ACTION BUTTONS */}
            <div className="mt-5 flex flex-col gap-2.5 sm:flex-row">
              <button
                type="button"
                onClick={() => setEditing({})}
                className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm transition-colors duration-200 hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 sm:w-auto"
              >
                <Plus size={17} aria-hidden="true" />
                New project
              </button>

              <div className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm text-slate-300 backdrop-blur sm:w-auto">
                <FolderKanban size={16} aria-hidden="true" />
                {summary.total} projects
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:w-[390px]">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur">
              <div className="text-xs text-slate-400">Active</div>
              <div className="mt-2 text-2xl font-bold">{summary.active}</div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur">
              <div className="text-xs text-slate-400">Completed</div>
              <div className="mt-2 text-2xl font-bold">{summary.completed}</div>
            </div>

            <div className="col-span-2 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur sm:col-span-1">
              <div className="text-xs text-slate-400">Progress</div>
              <div className="mt-2 text-2xl font-bold">
                {summary.overallProgress}%
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SUMMARY */}
      <section className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
        <SummaryCard
          icon={FolderKanban}
          iconClass="bg-violet-500/10 text-violet-600"
          value={summary.total}
          label="Total projects"
        />

        <SummaryCard
          icon={Layers3}
          iconClass="bg-blue-500/10 text-blue-600"
          value={summary.active}
          label="Active projects"
        />

        <SummaryCard
          icon={CheckCircle2}
          iconClass="bg-emerald-500/10 text-emerald-600"
          value={summary.completed}
          label="Completed projects"
        />

        <SummaryCard
          icon={Layers3}
          iconClass="bg-cyan-500/10 text-cyan-600"
          value={summary.totalTasks}
          label="Total tasks"
        />
      </section>

      {/* SEARCH + FILTER */}
      <section className="rounded-2xl border border-line bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="font-bold text-slate-900">Find a project</h2>
            <p className="mt-1 text-sm text-muted">
              Search your workspace or filter projects by status.
            </p>
          </div>

          <div className="flex w-full flex-col gap-3 sm:flex-row lg:w-auto">
            <div className="relative sm:min-w-[300px]">
              <Search
                size={17}
                aria-hidden="true"
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
              />

              <input
                className="input h-11 w-full pl-10 pr-10"
                placeholder="Search projects..."
                aria-label="Search projects"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />

              {search && (
                <button
                  type="button"
                  onClick={() => setSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
                  aria-label="Clear search"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            <select
              className="input h-11 sm:min-w-[180px]"
              aria-label="Filter by status"
              value={status}
              onChange={(event) => setStatus(event.target.value)}
            >
              {STATUS_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {hasFilters && (
          <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-4">
            <span className="text-xs font-medium text-muted">
              Active filters:
            </span>

            {search && (
              <span className="max-w-full truncate rounded-full bg-slate-100 px-3 py-1 text-xs font-medium">
                Search: {search}
              </span>
            )}

            {status && (
              <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-medium text-violet-700">
                {PROJECT_STATUS[status]?.label || status}
              </span>
            )}

            <button
              type="button"
              onClick={clearFilters}
              className="ml-auto rounded-md px-2 py-1 text-xs font-semibold text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
            >
              Clear all
            </button>
          </div>
        )}
      </section>

      {/* PROJECT LIST */}
      <section>
        {loading ? (
          <div className="rounded-2xl border border-line bg-white p-10 shadow-sm">
            <Spinner label="Loading projects" />
          </div>
        ) : error ? (
          <ErrorBox message={error} onRetry={load} />
        ) : projects.length === 0 ? (
          <div className="rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
            <EmptyState
              icon={FolderKanban}
              title={
                hasFilters
                  ? 'No projects match these filters'
                  : 'No projects yet'
              }
              text={
                hasFilters
                  ? 'Try a different search or status.'
                  : 'Create your first project, then break it into tasks.'
              }
              action={
                hasFilters ? (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={clearFilters}
                  >
                    <X size={16} />
                    Clear filters
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => setEditing({})}
                  >
                    <Plus size={16} />
                    New project
                  </button>
                )
              }
            />
          </div>
        ) : (
          <>
            <div className="mb-4 flex items-end justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  All projects
                </h2>
                <p className="mt-1 text-sm text-muted">
                  Showing {projects.length} project
                  {projects.length !== 1 ? 's' : ''}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setEditing({})}
                className="hidden min-h-11 items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 sm:inline-flex"
              >
                <Plus size={16} />
                New project
              </button>
            </div>

            <ul className="grid gap-4 sm:gap-5 md:grid-cols-2 xl:grid-cols-3">
              {projects.map((project) => {
                const taskCount = project.taskCount || 0;
                const doneCount = project.doneCount || 0;

                const percent = taskCount
                  ? Math.round((doneCount / taskCount) * 100)
                  : 0;

                const ProjectIcon = getProjectIcon(project.status);
                const accent = getProjectAccent(project.status);

                return (
                  <li key={project.id}>
                    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-xl">
                      <div className={`h-1 w-full bg-gradient-to-r ${accent.line}`} />

                      <div className="flex flex-1 flex-col p-4 sm:p-5">
                        <div className="flex items-start justify-between gap-3">
                          <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${accent.bg} ${accent.text}`}>
                            <ProjectIcon size={20} />
                          </div>

                          <Badge cls={PROJECT_STATUS[project.status]?.cls || ''}>
                            {PROJECT_STATUS[project.status]?.label || project.status}
                          </Badge>
                        </div>

                        <Link
                          to={`/projects/${project.id}`}
                          className="mt-5 block rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
                        >
                          <h3 className="line-clamp-2 text-lg font-bold leading-snug text-slate-900 transition group-hover:text-pine">
                            {project.title}
                          </h3>
                        </Link>

                        <p className="mt-2 line-clamp-2 min-h-[40px] text-sm leading-5 text-muted">
                          {project.description || 'No description added for this project yet.'}
                        </p>

                        <div className="mt-6">
                          <div className="flex items-center justify-between gap-3 text-xs">
                            <span className="font-medium text-muted">Project progress</span>
                            <span className="font-bold text-slate-900">{percent}%</span>
                          </div>

                          <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                            <div
                              className={`h-full rounded-full bg-gradient-to-r ${accent.line} transition-all duration-700`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>

                          <div className="mt-2 flex items-center justify-between gap-2 text-xs text-muted">
                            <span>
                              {doneCount} of {taskCount} tasks done
                            </span>
                            {taskCount === 0 && <span>No tasks yet</span>}
                          </div>
                        </div>

                        <div className="mt-6 grid grid-cols-2 gap-2.5 sm:gap-3">
                          <div className="rounded-xl bg-slate-50 p-3">
                            <div className="flex items-center gap-2 text-xs text-muted">
                              <Layers3 size={14} />
                              Tasks
                            </div>
                            <div className="mt-1 font-bold text-slate-900">
                              {taskCount}
                            </div>
                          </div>

                          <div className="rounded-xl bg-slate-50 p-3">
                            <div className="flex items-center gap-2 text-xs text-muted">
                              <CalendarDays size={14} />
                              Deadline
                            </div>
                            <div className="mt-1 truncate text-xs font-bold text-slate-900">
                              {formatDate(project.deadline)}
                            </div>
                          </div>
                        </div>

                        <div className="mt-auto flex flex-col gap-3 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-between">
                          <Link
                            to={`/projects/${project.id}`}
                            className="inline-flex min-h-10 items-center justify-center gap-2 rounded-xl px-3 text-sm font-semibold text-pine transition-colors duration-200 hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 sm:justify-start"
                          >
                            Open project
                            <ArrowUpRight size={15} />
                          </Link>

                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              className="flex h-10 w-10 items-center justify-center rounded-xl text-muted transition-colors duration-200 hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
                              aria-label={`Edit ${project.title}`}
                              onClick={() => setEditing(project)}
                            >
                              <Pencil size={16} />
                            </button>

                            <button
                              type="button"
                              className="flex h-10 w-10 items-center justify-center rounded-xl text-muted transition-colors duration-200 hover:bg-rose-50 hover:text-rose-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-200"
                              aria-label={`Delete ${project.title}`}
                              onClick={() => setDeleting(project)}
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </article>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </section>

      {/* MOBILE NEW PROJECT */}
      {!loading && projects.length > 0 && (
        <div className="sm:hidden">
          <button
            type="button"
            onClick={() => setEditing({})}
            className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
          >
            <Plus size={16} />
            New project
          </button>
        </div>
      )}

      {/* QUICK INSIGHT */}
      {!loading && projects.length > 0 && (
        <section className="rounded-2xl border border-line bg-gradient-to-r from-violet-50 via-white to-blue-50 p-5 shadow-sm sm:p-6">
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm">
                <Clock3 size={19} />
              </div>

              <div>
                <h3 className="font-bold text-slate-900">
                  Keep the momentum going
                </h3>
                <p className="mt-1 max-w-2xl text-sm leading-5 text-muted">
                  You have completed {summary.completedTasks} of{' '}
                  {summary.totalTasks} tasks across your current projects.
                  Keep working through the active projects to reach your next
                  milestone.
                </p>
              </div>
            </div>

            <Link
              to="/"
              className="inline-flex min-h-11 w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors duration-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 sm:w-auto"
            >
              View dashboard
              <ArrowUpRight size={15} />
            </Link>
          </div>
        </section>
      )}

      {/* MODALS */}
      {editing && (
        <ProjectForm
          project={editing.id ? editing : null}
          onClose={() => setEditing(null)}
          onSaved={() => {
            toast.success(editing.id ? 'Project updated' : 'Project created');
            setEditing(null);
            load();
          }}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete project?"
          busy={busy}
          onConfirm={remove}
          onClose={() => setDeleting(null)}
          text={`"${deleting.title}" and all of its ${
            deleting.taskCount
          } tasks will be permanently deleted.`}
        />
      )}
    </div>
  );
}

function SummaryCard({ icon: Icon, iconClass, value, label }) {
  return (
    <div className="group rounded-2xl border border-line bg-white p-4 shadow-sm transition duration-200 hover:-translate-y-1 hover:shadow-lg sm:p-5">
      <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${iconClass}`}>
        <Icon size={19} />
      </div>

      <div className="mt-4 text-2xl font-bold tracking-tight text-slate-900 sm:mt-5">
        {value}
      </div>

      <p className="mt-1 text-xs font-medium leading-5 text-muted">
        {label}
      </p>
    </div>
  );
}
