import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Circle,
  Clock3,
  FolderKanban,
  ListChecks,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Target,
  Trash2,
  UserRound,
  X,
} from 'lucide-react';

import api, { parseError } from '../api/client.js';
import Spinner from '../components/Spinner.jsx';
import ErrorBox from '../components/ErrorBox.jsx';
import EmptyState from '../components/EmptyState.jsx';
import Badge from '../components/Badge.jsx';
import ProjectForm from '../components/ProjectForm.jsx';
import TaskForm from '../components/TaskForm.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../context/ToastContext.jsx';
import {
  PROJECT_STATUS,
  PRIORITY,
  formatDate,
  isOverdue,
} from '../utils/format.js';

const COLUMNS = [
  {
    key: 'TODO',
    label: 'To do',
    description: 'Waiting to start',
    icon: Circle,
    iconClass: 'text-slate-600',
    iconBg: 'bg-slate-100',
    topLine: 'from-slate-400 to-slate-600',
  },
  {
    key: 'IN_PROGRESS',
    label: 'In progress',
    description: 'Currently working',
    icon: Clock3,
    iconClass: 'text-blue-600',
    iconBg: 'bg-blue-50',
    topLine: 'from-blue-500 to-cyan-400',
  },
  {
    key: 'DONE',
    label: 'Done',
    description: 'Successfully completed',
    icon: CheckCircle2,
    iconClass: 'text-emerald-600',
    iconBg: 'bg-emerald-50',
    topLine: 'from-emerald-500 to-cyan-400',
  },
];

function getCompletionPercent(tasks) {
  if (!tasks.length) return 0;

  const completed = tasks.filter(
    (task) => task.status === 'DONE'
  ).length;

  return Math.round((completed / tasks.length) * 100);
}

function getInitials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);

  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [taskForm, setTaskForm] = useState(null);
  const [editProject, setEditProject] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError('');

    Promise.all([
      api.get(`/projects/${id}`),
      api.get(`/projects/${id}/tasks`, {
        params: {
          ...(search && { search }),
          ...(priority && { priority }),
        },
      }),
    ])
      .then(([projectResponse, taskResponse]) => {
        setProject(projectResponse.data.project);
        setTasks(taskResponse.data.tasks);
      })
      .catch((e) => {
        setError(parseError(e).message);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id, search, priority]);

  useEffect(() => {
    const timer = setTimeout(load, 250);

    return () => clearTimeout(timer);
  }, [load]);

  const move = async (task, direction) => {
    const currentIndex = COLUMNS.findIndex(
      (column) => column.key === task.status
    );

    const nextIndex = currentIndex + direction;

    if (
      nextIndex < 0 ||
      nextIndex >= COLUMNS.length
    ) {
      return;
    }

    try {
      const response = await api.patch(`/tasks/${task.id}`, {
        status: COLUMNS[nextIndex].key,
      });

      setTasks((currentTasks) =>
        currentTasks.map((item) =>
          item.id === task.id
            ? response.data.task
            : item
        )
      );

      toast.success(
        `Task moved to ${COLUMNS[nextIndex].label}`
      );
    } catch (e) {
      toast.error(parseError(e).message);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;

    setBusy(true);

    try {
      if (deleteTarget.type === 'project') {
        await api.delete(`/projects/${id}`);

        toast.success('Project deleted');
        navigate('/projects');
      } else {
        await api.delete(
          `/tasks/${deleteTarget.item.id}`
        );

        toast.success('Task deleted');
        setDeleteTarget(null);

        load();
      }
    } catch (e) {
      toast.error(parseError(e).message);
    } finally {
      setBusy(false);
    }
  };

  const stats = useMemo(() => {
    const total = tasks.length;

    const todo = tasks.filter(
      (task) => task.status === 'TODO'
    ).length;

    const inProgress = tasks.filter(
      (task) => task.status === 'IN_PROGRESS'
    ).length;

    const done = tasks.filter(
      (task) => task.status === 'DONE'
    ).length;

    const overdue = tasks.filter((task) =>
      isOverdue(task.deadline, task.status)
    ).length;

    return {
      total,
      todo,
      inProgress,
      done,
      overdue,
    };
  }, [tasks]);

  const progress = useMemo(
    () => getCompletionPercent(tasks),
    [tasks]
  );

  const hasFilters = Boolean(search || priority);

  if (loading && !project) {
    return (
      <div className="rounded-3xl border border-line bg-white p-12 shadow-sm">
        <Spinner label="Loading project" />
      </div>
    );
  }

  if (error && !project) {
    return (
      <div className="space-y-4">
        <ErrorBox message={error} onRetry={load} />

        <Link
          to="/projects"
          className="btn-ghost focus:outline-none focus:ring-2 focus:ring-slate-300"
        >
          <ArrowLeft size={16} />
          Back to projects
        </Link>
      </div>
    );
  }

  if (!project) {
    return null;
  }

  return (
    <div className="space-y-7 pb-12 sm:space-y-9">
      {/* BACK */}
      <Link
        to="/projects"
        className="group inline-flex min-h-9 items-center gap-2 rounded-xl px-2 text-sm font-semibold text-muted transition-all hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
      >
        <ArrowLeft
          size={16}
          className="transition-transform duration-200 group-hover:-translate-x-1"
        />
        Projects
      </Link>

      {/* HERO */}
      <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 px-5 py-6 text-white shadow-2xl sm:px-7 sm:py-8 lg:px-9 lg:py-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-violet-500/20 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-40 left-1/3 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute right-1/3 top-1/2 h-40 w-40 rounded-full bg-cyan-400/5 blur-3xl"
        />

        <div className="relative z-10">
          <div className="flex flex-col gap-8 xl:flex-row xl:items-start xl:justify-between">
            <div className="min-w-0 max-w-3xl">
              <div className="mb-5 flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-xs font-semibold text-slate-200 backdrop-blur-xl">
                  <Sparkles size={14} />
                  Project workspace
                </span>

                <Badge
                  cls={
                    PROJECT_STATUS[project.status]?.cls || ''
                  }
                >
                  {PROJECT_STATUS[project.status]?.label ||
                    project.status}
                </Badge>
              </div>

              <h1 className="break-words text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
                {project.title}
              </h1>

              {project.description && (
                <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-300 sm:text-base">
                  {project.description}
                </p>
              )}

              <div className="mt-6 flex flex-col gap-3 text-sm text-slate-300 sm:flex-row sm:flex-wrap sm:items-center sm:gap-x-6">
                <span className="inline-flex items-center gap-2">
                  <CalendarDays size={15} />
                  Deadline: {formatDate(project.deadline)}
                </span>

                <span className="inline-flex items-center gap-2">
                  <ListChecks size={15} />
                  {stats.total}{' '}
                  {stats.total === 1 ? 'task' : 'tasks'}
                </span>

                {stats.overdue > 0 && (
                  <span className="inline-flex items-center gap-2 font-semibold text-red-300">
                    <Target size={15} />
                    {stats.overdue} overdue
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 sm:flex sm:shrink-0">
              <button
                type="button"
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur-xl transition-all hover:-translate-y-0.5 hover:bg-white/15 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-white/60"
                onClick={() => setEditProject(true)}
              >
                <Pencil size={16} />
                Edit
              </button>

              <button
                type="button"
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-2.5 text-sm font-semibold text-red-200 backdrop-blur-xl transition-all hover:-translate-y-0.5 hover:bg-red-500/20 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-red-300/60"
                onClick={() =>
                  setDeleteTarget({
                    type: 'project',
                  })
                }
              >
                <Trash2 size={16} />
                Delete
              </button>
            </div>
          </div>

          {/* HERO PROGRESS */}
          <div className="mt-9 max-w-3xl rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl sm:p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Overall progress
                </p>
                <p className="mt-1 text-sm font-medium text-slate-200">
                  {stats.done} of {stats.total} tasks completed
                </p>
              </div>

              <span className="text-2xl font-bold text-white">
                {progress}%
              </span>
            </div>

            <div
              className="h-2.5 overflow-hidden rounded-full bg-white/10"
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin="0"
              aria-valuemax="100"
              aria-label="Project completion"
            >
              <div
                className="h-full rounded-full bg-gradient-to-r from-white via-slate-200 to-white transition-all duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section>
        <div className="mb-4 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-muted">
              Project overview
            </p>
            <h2 className="mt-1 text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
              Project performance
            </h2>
          </div>

          <div className="hidden items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-muted sm:flex">
            <FolderKanban size={14} />
            Live statistics
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <StatCard
            icon={ListChecks}
            label="Total"
            value={stats.total}
            description="All project tasks"
            iconClass="bg-violet-500/10 text-violet-600"
          />

          <StatCard
            icon={Circle}
            label="To do"
            value={stats.todo}
            description="Waiting to start"
            iconClass="bg-slate-500/10 text-slate-600"
          />

          <StatCard
            icon={Clock3}
            label="Active"
            value={stats.inProgress}
            description="In progress"
            iconClass="bg-blue-500/10 text-blue-600"
          />

          <StatCard
            icon={CheckCircle2}
            label="Done"
            value={stats.done}
            description="Completed"
            iconClass="bg-emerald-500/10 text-emerald-600"
          />

          <StatCard
            icon={Target}
            label="Overdue"
            value={stats.overdue}
            description={
              stats.overdue === 0
                ? 'Everything on track'
                : 'Needs attention'
            }
            iconClass="bg-rose-500/10 text-rose-600"
            valueClass={
              stats.overdue > 0
                ? 'text-rose-600'
                : 'text-slate-900'
            }
            className="col-span-2 sm:col-span-1"
          />
        </div>
      </section>

      {/* TASK MANAGEMENT */}
      <section className="overflow-hidden rounded-3xl border border-line bg-white shadow-sm">
        <div className="border-b border-line bg-gradient-to-r from-slate-50 via-white to-violet-50/40 px-5 py-5 sm:px-6">
          <div className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
                  <ListChecks size={17} />
                </div>

                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted">
                    Workspace
                  </p>

                  <h2 className="text-lg font-bold text-slate-900">
                    Project tasks
                  </h2>
                </div>
              </div>

              <p className="mt-3 text-sm text-muted">
                Manage, filter and move every task through the workflow.
              </p>
            </div>

            <div className="grid gap-2.5 sm:grid-cols-[minmax(0,1fr)_auto_auto] xl:min-w-[650px]">
              <div className="relative min-w-0">
                <Search
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
                />

                <input
                  className="input h-11 w-full border-slate-200 bg-white pl-10 pr-10 shadow-sm"
                  placeholder="Search tasks..."
                  aria-label="Search tasks"
                  value={search}
                  onChange={(event) =>
                    setSearch(event.target.value)
                  }
                />

                {search && (
                  <button
                    type="button"
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                    aria-label="Clear search"
                  >
                    <X size={15} />
                  </button>
                )}
              </div>

              <select
                className="input h-11 w-full border-slate-200 bg-white shadow-sm sm:w-auto"
                aria-label="Filter by priority"
                value={priority}
                onChange={(event) =>
                  setPriority(event.target.value)
                }
              >
                <option value="">Any priority</option>
                <option value="HIGH">High priority</option>
                <option value="MEDIUM">Medium priority</option>
                <option value="LOW">Low priority</option>
              </select>

              <button
                type="button"
                className="btn-primary min-h-11 whitespace-nowrap shadow-sm"
                onClick={() => setTaskForm({})}
              >
                <Plus size={16} />
                Add task
              </button>
            </div>
          </div>

          {hasFilters && (
            <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-line pt-4">
              <span className="text-xs font-semibold text-muted">
                Active filters:
              </span>

              {search && (
                <button
                  type="button"
                  className="max-w-full truncate rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  onClick={() => setSearch('')}
                >
                  Search: {search} ×
                </button>
              )}

              {priority && (
                <button
                  type="button"
                  className="rounded-full bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-700 transition hover:bg-violet-100 focus:outline-none focus:ring-2 focus:ring-violet-200"
                  onClick={() => setPriority('')}
                >
                  Priority:{' '}
                  {PRIORITY[priority]?.label ||
                    priority}{' '}
                  ×
                </button>
              )}

              <button
                type="button"
                className="rounded-md px-2 py-1 text-xs font-semibold text-muted transition hover:bg-slate-100 hover:text-slate-900 hover:underline focus:outline-none focus:ring-2 focus:ring-slate-300"
                onClick={() => {
                  setSearch('');
                  setPriority('');
                }}
              >
                Clear all
              </button>
            </div>
          )}
        </div>
      </section>

      {/* TASK BOARD */}
      <section>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-muted">
              Workflow
            </p>

            <h2 className="mt-1 text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
              Task board
            </h2>
          </div>

          <span className="w-fit rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-muted">
            {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}
          </span>
        </div>

        {error ? (
          <ErrorBox message={error} onRetry={load} />
        ) : loading ? (
          <div className="rounded-3xl border border-line bg-white p-10 shadow-sm">
            <Spinner label="Loading tasks" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="rounded-3xl border border-line bg-white p-6 shadow-sm sm:p-10">
            <EmptyState
              icon={ListChecks}
              title={
                hasFilters
                  ? 'No tasks match these filters'
                  : 'No tasks in this project yet'
              }
              text={
                hasFilters
                  ? 'Try clearing the search or priority filter.'
                  : 'Add the first task to get this project moving.'
              }
              action={
                !hasFilters && (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => setTaskForm({})}
                  >
                    <Plus size={16} />
                    Add task
                  </button>
                )
              }
            />
          </div>
        ) : (
          <div className="grid gap-4 xl:grid-cols-3">
            {COLUMNS.map((column) => {
              const ColumnIcon = column.icon;

              const items = tasks.filter(
                (task) => task.status === column.key
              );

              return (
                <section
                  key={column.key}
                  className="group/column relative min-w-0 overflow-hidden rounded-3xl border border-line bg-gradient-to-b from-slate-50 to-white p-3 shadow-sm transition duration-200 hover:shadow-lg sm:p-4"
                  aria-label={column.label}
                >
                  {/* COLUMN TOP LINE */}
                  <div
                    className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${column.topLine}`}
                  />

                  {/* COLUMN HEADER */}
                  <div className="rounded-2xl border border-line bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${column.iconBg} ${column.iconClass}`}
                        >
                          <ColumnIcon size={18} />
                        </div>

                        <div className="min-w-0">
                          <h3 className="truncate font-bold text-slate-900">
                            {column.label}
                          </h3>

                          <p className="mt-0.5 truncate text-[11px] text-muted">
                            {column.description}
                          </p>
                        </div>
                      </div>

                      <span className="flex h-8 min-w-8 shrink-0 items-center justify-center rounded-full bg-slate-900 px-2 text-xs font-bold text-white shadow-sm">
                        {items.length}
                      </span>
                    </div>
                  </div>

                  {/* TASKS */}
                  <ul className="mt-3 space-y-3">
                    {items.length === 0 && (
                      <li className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-3 py-10 text-center">
                        <div
                          className={`mx-auto flex h-10 w-10 items-center justify-center rounded-xl ${column.iconBg} ${column.iconClass}`}
                        >
                          <ColumnIcon size={18} />
                        </div>

                        <p className="mt-3 text-xs font-semibold text-muted">
                          Nothing here yet
                        </p>

                        <p className="mt-1 text-[11px] text-slate-400">
                          Tasks will appear here
                        </p>
                      </li>
                    )}

                    {items.map((task) => {
                      const late = isOverdue(
                        task.deadline,
                        task.status
                      );

                      return (
                        <li
                          key={task.id}
                          className={`group/task relative overflow-hidden rounded-2xl border bg-white shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-xl ${
                            late
                              ? 'border-rose-200'
                              : 'border-line hover:border-slate-300'
                          }`}
                        >
                          {/* TASK ACCENT */}
                          <div
                            className={`h-1 w-full ${
                              late
                                ? 'bg-gradient-to-r from-rose-400 to-orange-400'
                                : `bg-gradient-to-r ${column.topLine}`
                            }`}
                          />

                          <div className="p-4">
                            {/* TITLE */}
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0 flex-1">
                                <h4 className="break-words font-bold leading-snug text-slate-900 transition-colors group-hover/task:text-slate-700">
                                  {task.title}
                                </h4>

                                {task.description && (
                                  <p className="mt-1.5 line-clamp-2 text-xs leading-5 text-muted">
                                    {task.description}
                                  </p>
                                )}
                              </div>

                              <span
                                className={`shrink-0 rounded-full bg-slate-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${
                                  PRIORITY[task.priority]?.cls ||
                                  'text-slate-600'
                                }`}
                              >
                                {PRIORITY[task.priority]?.label ||
                                  task.priority}
                              </span>
                            </div>

                            {/* META */}
                            <div className="mt-4 rounded-xl bg-slate-50 p-3">
                              <div
                                className={`flex min-w-0 items-center gap-2 text-xs ${
                                  late
                                    ? 'font-bold text-rose-600'
                                    : 'text-muted'
                                }`}
                              >
                                <CalendarDays
                                  size={14}
                                  className="shrink-0"
                                />

                                <span className="truncate">
                                  {late
                                    ? 'Overdue • '
                                    : ''}
                                  {formatDate(task.deadline)}
                                </span>
                              </div>

                              <div className="mt-2.5 flex min-w-0 items-center gap-2 text-xs text-muted">
                                {task.assignedUser?.avatar ? (
                                  <img
                                    src={task.assignedUser.avatar}
                                    alt=""
                                    className="h-6 w-6 shrink-0 rounded-full object-cover"
                                  />
                                ) : (
                                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white text-[9px] font-bold text-slate-700 shadow-sm">
                                    {task.assignedUser
                                      ? getInitials(
                                          task.assignedUser.name
                                        )
                                      : <UserRound size={12} />}
                                  </span>
                                )}

                                <span className="truncate">
                                  {task.assignedUser?.name ||
                                    'Unassigned'}
                                </span>
                              </div>
                            </div>

                            {/* ACTIONS */}
                            <div className="mt-4 flex items-center justify-between border-t border-line pt-3">
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-20 focus:outline-none focus:ring-2 focus:ring-slate-300"
                                  aria-label="Move to previous column"
                                  disabled={
                                    column.key === 'TODO'
                                  }
                                  onClick={() =>
                                    move(task, -1)
                                  }
                                >
                                  <ArrowLeft size={14} />
                                </button>

                                <button
                                  type="button"
                                  className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-20 focus:outline-none focus:ring-2 focus:ring-slate-300"
                                  aria-label="Move to next column"
                                  disabled={
                                    column.key === 'DONE'
                                  }
                                  onClick={() =>
                                    move(task, 1)
                                  }
                                >
                                  <ArrowRight size={14} />
                                </button>
                              </div>

                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                                  aria-label={`Edit ${task.title}`}
                                  onClick={() =>
                                    setTaskForm(task)
                                  }
                                >
                                  <Pencil size={14} />
                                </button>

                                <button
                                  type="button"
                                  className="flex h-8 w-8 items-center justify-center rounded-lg text-rose-500 transition hover:bg-rose-50 hover:text-rose-600 focus:outline-none focus:ring-2 focus:ring-rose-200"
                                  aria-label={`Delete ${task.title}`}
                                  onClick={() =>
                                    setDeleteTarget({
                                      type: 'task',
                                      item: task,
                                    })
                                  }
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </section>
              );
            })}
          </div>
        )}
      </section>

      {/* BOTTOM INSIGHT */}
      {!loading && tasks.length > 0 && (
        <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-r from-violet-50 via-white to-blue-50 p-5 shadow-sm sm:p-6">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-violet-200/30 blur-3xl"
          />

          <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm">
                <Sparkles size={19} />
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-violet-600">
                  Project insight
                </p>

                <h3 className="mt-1 font-bold text-slate-900">
                  {progress === 100
                    ? 'Amazing — this project is complete!'
                    : stats.overdue > 0
                      ? 'A few tasks need your attention'
                      : 'Keep the momentum going'}
                </h3>

                <p className="mt-1 max-w-2xl text-sm leading-5 text-muted">
                  {progress === 100
                    ? 'Every task in this project has been completed.'
                    : `${stats.done} of ${stats.total} tasks are complete. Continue working through the board to reach the next milestone.`}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setTaskForm({})}
              className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-slate-300"
            >
              <Plus size={16} />
              Add task
            </button>
          </div>
        </section>
      )}

      {/* TASK FORM */}
      {taskForm && (
        <TaskForm
          projectId={id}
          task={taskForm.id ? taskForm : null}
          onClose={() => setTaskForm(null)}
          onSaved={() => {
            toast.success(
              taskForm.id ? 'Task updated' : 'Task added'
            );

            setTaskForm(null);
            load();
          }}
        />
      )}

      {/* PROJECT FORM */}
      {editProject && (
        <ProjectForm
          project={project}
          onClose={() => setEditProject(false)}
          onSaved={(updatedProject) => {
            toast.success('Project updated');

            setProject(updatedProject);
            setEditProject(false);
          }}
        />
      )}

      {/* DELETE CONFIRMATION */}
      {deleteTarget && (
        <ConfirmDialog
          busy={busy}
          onConfirm={confirmDelete}
          onClose={() => setDeleteTarget(null)}
          title={
            deleteTarget.type === 'project'
              ? 'Delete project?'
              : 'Delete task?'
          }
          text={
            deleteTarget.type === 'project'
              ? `"${project.title}" and all of its tasks will be permanently deleted.`
              : `"${deleteTarget.item.title}" will be permanently deleted.`
          }
        />
      )}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  description,
  iconClass,
  valueClass = '',
  className = '',
}) {
  return (
    <div
      className={`group rounded-2xl border border-line bg-white p-4 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-xl sm:p-5 ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <span className="text-[11px] font-bold uppercase tracking-wider text-muted">
          {label}
        </span>

        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${iconClass} transition-transform duration-200 group-hover:scale-105`}
        >
          <Icon size={18} />
        </div>
      </div>

      <p
        className={`mt-4 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl ${valueClass}`}
      >
        {value}
      </p>

      <p className="mt-1 text-xs font-medium leading-5 text-muted">
        {description}
      </p>
    </div>
  );
}