
import {
  Check,
  CheckCircle2,
  Clock3,
  ListChecks,
  Workflow,
} from 'lucide-react';

const SAMPLE = [
  { t: 'Draft launch checklist', done: true },
  { t: 'Review pricing page copy', done: true },
  { t: 'Ship onboarding emails', done: false },
];

export default function AuthLayout({
  title,
  subtitle,
  children,
  footer,
}) {
  return (
    <div className="min-h-screen bg-slate-50 lg:grid lg:grid-cols-[0.95fr_1.05fr]">
      {/* LEFT BRAND PANEL */}
      <aside
        aria-label="TaskFlow introduction"
        className="relative hidden overflow-hidden bg-slate-950 text-white lg:flex lg:min-h-screen lg:flex-col lg:justify-between lg:p-10 xl:p-14"
      >
        {/* BACKGROUND GLOW */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-24 top-20 h-72 w-72 rounded-full bg-violet-600/20 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-24 right-0 h-80 w-80 rounded-full bg-emerald-500/10 blur-3xl"
        />

        <div
          aria-hidden="true"
          className="pointer-events-none absolute right-20 top-1/3 h-48 w-48 rounded-full bg-blue-500/10 blur-3xl"
        />

        {/* BRAND */}
        <div className="relative z-10 flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/10 backdrop-blur">
            <Workflow
              size={22}
              className="text-emerald-300"
              strokeWidth={2.2}
              aria-hidden="true"
            />
          </div>

          <span className="font-display text-2xl font-bold tracking-tight">
            TaskFlow
          </span>
        </div>

        {/* MAIN CONTENT */}
        <div className="relative z-10 max-w-xl">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/70 backdrop-blur">
            <span
              aria-hidden="true"
              className="h-1.5 w-1.5 rounded-full bg-emerald-400"
            />
            Stay organized. Move faster.
          </div>

          <h2 className="font-display text-4xl font-bold leading-[1.08] tracking-tight xl:text-5xl">
            Projects stay on track when every task has an owner and a date.
          </h2>

          <p className="mt-5 max-w-lg text-sm leading-6 text-white/55">
            Plan your work, organize tasks, and keep your projects moving
            without losing sight of what matters.
          </p>

          {/* SAMPLE TASKS */}
          <div
            aria-label="Example tasks"
            className="mt-8 max-w-md space-y-2.5"
          >
            {SAMPLE.map((item) => (
              <div
                key={item.t}
                className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3.5 backdrop-blur-sm transition-all duration-200 hover:border-white/15 hover:bg-white/[0.09]"
              >
                <span
                  aria-hidden="true"
                  className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${
                    item.done
                      ? 'bg-emerald-400 text-slate-950'
                      : 'border border-white/25 bg-white/5'
                  }`}
                >
                  {item.done && (
                    <Check size={13} strokeWidth={3} />
                  )}
                </span>

                <span
                  className={`text-sm ${
                    item.done
                      ? 'text-white/45 line-through'
                      : 'font-medium text-white/85'
                  }`}
                >
                  {item.t}
                </span>
              </div>
            ))}
          </div>

          {/* MINI STATS */}
          <div className="mt-8 grid max-w-md grid-cols-3 gap-2.5">
            <MiniStat
              icon={ListChecks}
              value="Tasks"
              label="organized"
            />

            <MiniStat
              icon={Clock3}
              value="Dates"
              label="tracked"
            />

            <MiniStat
              icon={CheckCircle2}
              value="Progress"
              label="visible"
            />
          </div>
        </div>

        {/* FOOTER */}
        <p className="relative z-10 text-xs text-white/35">
          Plan projects, assign tasks, and track what is overdue.
        </p>
      </aside>

      {/* RIGHT AUTH AREA */}
      <main className="flex min-h-screen items-center justify-center px-4 py-8 sm:px-6 lg:px-10">
        <div className="w-full max-w-md">
          {/* MOBILE BRAND */}
          <div className="mb-8 flex items-center justify-center lg:hidden">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-white shadow-lg">
                <Workflow
                  size={21}
                  strokeWidth={2.2}
                  aria-hidden="true"
                />
              </div>

              <span className="font-display text-xl font-bold tracking-tight text-slate-900">
                TaskFlow
              </span>
            </div>
          </div>

          {/* AUTH CARD */}
          <div className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-xl shadow-slate-200/60 sm:p-7">
            {/* HEADER */}
            <div>
              <div
                aria-hidden="true"
                className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700 lg:hidden"
              >
                <Workflow size={19} />
              </div>

              <h1 className="font-display text-3xl font-bold tracking-tight text-slate-950">
                {title}
              </h1>

              {subtitle && (
                <p className="mt-2 text-sm leading-6 text-muted">
                  {subtitle}
                </p>
              )}
            </div>

            {/* PAGE CONTENT */}
            <div className="mt-7">
              {children}
            </div>

            {/* FOOTER */}
            {footer && (
              <div className="mt-7 border-t border-slate-100 pt-5">
                <p className="text-center text-sm text-muted">
                  {footer}
                </p>
              </div>
            )}
          </div>

          {/* SMALL FOOTNOTE */}
          <p className="mt-5 text-center text-[11px] leading-5 text-slate-400">
            TaskFlow workspace · Secure account access
          </p>
        </div>
      </main>
    </div>
  );
}

function MiniStat({ icon: Icon, value, label }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-3 backdrop-blur-sm">
      <Icon
        size={15}
        className="text-white/55"
        aria-hidden="true"
      />

      <p className="mt-2 text-xs font-bold text-white/80">
        {value}
      </p>

      <p className="mt-0.5 text-[10px] text-white/35">
        {label}
      </p>
    </div>
  );
}
