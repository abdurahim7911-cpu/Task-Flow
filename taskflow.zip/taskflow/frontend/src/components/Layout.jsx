
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderKanban,
  UserRound,
  Users,
  LogOut,
  Workflow,
} from 'lucide-react';

import { useAuth } from '../context/AuthContext.jsx';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const links = [
    {
      to: '/',
      label: 'Dashboard',
      icon: LayoutDashboard,
      end: true,
    },
    {
      to: '/projects',
      label: 'Projects',
      icon: FolderKanban,
    },
    {
      to: '/profile',
      label: 'Profile',
      icon: UserRound,
    },
    ...(user?.role === 'ADMIN'
      ? [
          {
            to: '/admin/users',
            label: 'Users',
            icon: Users,
          },
        ]
      : []),
  ];

  const linkCls = ({ isActive }) =>
    [
      'group flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5',
      'text-sm font-semibold transition-all duration-200',
      'focus:outline-none focus-visible:ring-2 focus-visible:ring-pine',
      'focus-visible:ring-offset-2',
      isActive
        ? 'bg-slate-900 text-white shadow-sm'
        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
    ].join(' ');

  const handleLogout = async () => {
    try {
      await logout();
    } finally {
      navigate('/login', { replace: true });
    }
  };

  return (
    <div className="min-h-screen bg-paper">
      <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-5 gap-y-3 px-4 py-3 sm:px-6 lg:px-8">
          {/* LOGO */}
          <NavLink
            to="/"
            aria-label="TaskFlow home"
            className="group flex shrink-0 items-center gap-2 rounded-xl font-display text-xl font-bold text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-pine focus-visible:ring-offset-2"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-white transition-colors duration-200 group-hover:bg-slate-800">
              <Workflow
                size={23}
                strokeWidth={2.2}
                aria-hidden="true"
              />
            </span>

            <span>TaskFlow</span>
          </NavLink>

          {/* NAVIGATION */}
          <nav
            className="order-3 flex w-full min-w-0 gap-1 overflow-x-auto pb-1 sm:order-none sm:w-auto sm:flex-1"
            aria-label="Main navigation"
          >
            {links.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={linkCls}
              >
                <Icon
                  size={17}
                  strokeWidth={2}
                  aria-hidden="true"
                  className="shrink-0 transition-transform duration-200 group-hover:scale-105"
                />

                <span>{label}</span>
              </NavLink>
            ))}
          </nav>

          {/* USER AND LOGOUT */}
          <div className="ml-auto flex shrink-0 items-center gap-2 sm:gap-3">
            {user && (
              <div
                className="hidden max-w-40 items-center gap-2 rounded-xl border border-line bg-white px-3 py-2 sm:flex"
                title={user.name}
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-700">
                  <UserRound
                    size={16}
                    aria-hidden="true"
                  />
                </span>

                <span className="max-w-24 truncate text-sm font-semibold text-slate-700">
                  {user.name}
                </span>
              </div>
            )}

            <button
              type="button"
              className="btn-ghost !px-3 transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-pine focus-visible:ring-offset-2"
              onClick={handleLogout}
              aria-label="Log out"
              title="Log out"
            >
              <LogOut
                size={17}
                aria-hidden="true"
              />

              <span className="hidden sm:inline">
                Log out
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* PAGE CONTENT */}
      <main className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        <Outlet />
      </main>
    </div>
  );
}
