
import {
  AlertTriangle,
  Check,
  Loader2,
  X,
} from 'lucide-react';

import Modal from './Modal.jsx';

export default function ConfirmDialog({
  title,
  text,
  confirmLabel = 'Delete',
  busy = false,
  onConfirm,
  onClose,
}) {
  const handleConfirm = () => {
    if (busy || typeof onConfirm !== 'function') {
      return;
    }

    onConfirm();
  };

  return (
    <Modal title={title} onClose={onClose}>
      <div className="space-y-5">
        <div className="flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4">
          <div
            aria-hidden="true"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-100 text-red-600"
          >
            <AlertTriangle size={19} strokeWidth={2.2} />
          </div>

          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-red-800">
              This action cannot be undone
            </p>

            {text && (
              <p className="mt-1 break-words text-sm leading-6 text-red-700/80">
                {text}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button
            type="button"
            className="btn-ghost w-full sm:w-auto"
            onClick={onClose}
            disabled={busy}
          >
            <X size={16} strokeWidth={2.2} aria-hidden="true" />
            <span>Cancel</span>
          </button>

          <button
            type="button"
            className="btn-danger w-full sm:w-auto"
            onClick={handleConfirm}
            disabled={busy}
            aria-busy={busy}
          >
            {busy ? (
              <>
                <Loader2
                  size={16}
                  className="animate-spin"
                  aria-hidden="true"
                />
                <span>Please wait...</span>
              </>
            ) : (
              <>
                <Check
                  size={16}
                  strokeWidth={2.3}
                  aria-hidden="true"
                />
                <span>{confirmLabel}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </Modal>
  );
}
