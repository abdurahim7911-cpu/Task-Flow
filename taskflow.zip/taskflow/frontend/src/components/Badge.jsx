
const VARIANTS = {
  default: 'bg-slate-100 text-slate-700 ring-slate-200',
  success: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  warning: 'bg-amber-50 text-amber-700 ring-amber-200',
  danger: 'bg-red-50 text-red-700 ring-red-200',
  info: 'bg-blue-50 text-blue-700 ring-blue-200',
  violet: 'bg-violet-50 text-violet-700 ring-violet-200',
};

const SIZES = {
  sm: 'px-2 py-0.5 text-[11px]',
  md: 'px-2.5 py-1 text-xs',
};

export default function Badge({
  cls = '',
  children,
  variant = 'default',
  size = 'md',
  title,
}) {
  const colorClass = VARIANTS[variant] || VARIANTS.default;
  const sizeClass = SIZES[size] || SIZES.md;

  return (
    <span
      title={title}
      className={[
        'inline-flex max-w-full items-center gap-1.5',
        'rounded-full font-semibold leading-4',
        'ring-1 ring-inset',
        'whitespace-normal break-words',
        'transition-colors duration-200',
        colorClass,
        sizeClass,
        cls,
      ]
        .filter(Boolean)
        .join(' ')}
    >
      {children}
    </span>
  );
}
