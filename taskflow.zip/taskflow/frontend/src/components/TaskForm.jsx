import { useEffect, useState } from 'react';
import {
  CalendarDays,
  Check,
  ClipboardList,
  FileText,
  Loader2,
  Save,
  UserRound,
} from 'lucide-react';

import Modal from './Modal.jsx';
import Field from './Field.jsx';
import ErrorBox from './ErrorBox.jsx';

import api, {
  parseError,
} from '../api/client.js';

import { toDateInput } from '../utils/format.js';

export default function TaskForm({
  projectId,
  task,
  onClose,
  onSaved,
}) {
  const isEditing = Boolean(task);

  const [form, setForm] = useState({
    title: task?.title || '',
    description: task?.description || '',
    status: task?.status || 'TODO',
    priority: task?.priority || 'MEDIUM',
    deadline: toDateInput(task?.deadline),
    assignedUserId: task?.assignedUserId || '',
  });

  const [users, setUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(true);
  const [usersError, setUsersError] = useState('');

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;

    api
      .get('/users')
      .then((response) => {
        if (!active) return;

        setUsers(
          Array.isArray(response.data.users)
            ? response.data.users
            : []
        );
      })
      .catch(() => {
        if (!active) return;

        setUsersError(
          'Could not load the user list. You can still save the task.'
        );
      })
      .finally(() => {
        if (active) {
          setUsersLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, []);

  const setField = (key) => (event) => {
    const value = event.target.value;

    setForm((current) => ({
      ...current,
      [key]: value,
    }));

    setErrors((current) => {
      if (!current[key]) return current;

      const next = { ...current };
      delete next[key];

      return next;
    });

    setServerError('');
  };

  const validate = () => {
    const nextErrors = {};
    const title = form.title.trim();

    if (!title) {
      nextErrors.title = 'Title is required';
    } else if (title.length < 2) {
      nextErrors.title =
        'Title must be at least 2 characters';
    } else if (title.length > 160) {
      nextErrors.title =
        'Title must be at most 160 characters';
    }

    if (form.description.length > 2000) {
      nextErrors.description =
        'Description must be at most 2000 characters';
    }

    if (
      form.deadline &&
      Number.isNaN(Date.parse(form.deadline))
    ) {
      nextErrors.deadline = 'Enter a valid date';
    }

    return nextErrors;
  };

  const submit = async (event) => {
    event.preventDefault();

    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      return;
    }

    setSaving(true);
    setServerError('');

    try {
      const body = {
        title: form.title.trim(),
        description: form.description.trim() || null,
        status: form.status,
        priority: form.priority,
        deadline: form.deadline || null,
        assignedUserId: form.assignedUserId || null,
      };

      const response = isEditing
        ? await api.patch(`/tasks/${task.id}`, body)
        : await api.post(
            `/projects/${projectId}/tasks`,
            body
          );

      onSaved(response.data.task);
    } catch (error) {
      const parsed = parseError(error);

      setErrors(parsed.fields || {});
      setServerError(parsed.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={isEditing ? 'Edit task' : 'New task'}
      onClose={onClose}
    >
      <form
        onSubmit={submit}
        className="space-y-5"
        noValidate
      >
        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
            {isEditing ? (
              <Save size={18} strokeWidth={2.2} />
            ) : (
              <ClipboardList size={18} strokeWidth={2.2} />
            )}
          </div>

          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-900">
              {isEditing
                ? 'Update task details'
                : 'Create a new task'}
            </p>

            <p className="mt-0.5 text-xs leading-5 text-slate-500">
              Set the task details, priority and deadline.
            </p>
          </div>
        </div>

        <ErrorBox message={serverError} />

        <Field
          label="Title"
          htmlFor="task-title"
          error={errors.title}
          hint="Use a clear name that describes the task."
        >
          <div className="relative">
            <ClipboardList
              size={17}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />

            <input
              id="task-title"
              name="title"
              type="text"
              className={`input pl-10 ${
                errors.title ? 'input-error' : ''
              }`}
              value={form.title}
              onChange={setField('title')}
              placeholder="e.g. Build the login page"
              autoFocus
              autoComplete="off"
              maxLength={160}
              aria-invalid={Boolean(errors.title)}
              aria-describedby={
                errors.title
                  ? 'task-title-error'
                  : undefined
              }
            />
          </div>
        </Field>

        <Field
          label="Description"
          htmlFor="task-description"
          error={errors.description}
          hint="Optional details or instructions."
        >
          <div className="relative">
            <FileText
              size={17}
              className="pointer-events-none absolute left-3.5 top-3.5 text-slate-400"
              aria-hidden="true"
            />

            <textarea
              id="task-description"
              name="description"
              className={`input min-h-[100px] resize-y pl-10 ${
                errors.description ? 'input-error' : ''
              }`}
              rows={3}
              value={form.description}
              onChange={setField('description')}
              placeholder="Describe what needs to be done..."
              maxLength={2000}
              aria-invalid={Boolean(errors.description)}
              aria-describedby={
                errors.description
                  ? 'task-description-error'
                  : undefined
              }
            />
          </div>

          <div className="mt-1.5 flex justify-end">
            <span className="text-[11px] text-slate-400">
              {form.description.length}/2000
            </span>
          </div>
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field
            label="Status"
            htmlFor="task-status"
            hint="Current progress."
          >
            <select
              id="task-status"
              name="status"
              className="input"
              value={form.status}
              onChange={setField('status')}
            >
              <option value="TODO">To do</option>
              <option value="IN_PROGRESS">In progress</option>
              <option value="DONE">Done</option>
            </select>
          </Field>

          <Field
            label="Priority"
            htmlFor="task-priority"
            hint="How important is this task?"
          >
            <select
              id="task-priority"
              name="priority"
              className="input"
              value={form.priority}
              onChange={setField('priority')}
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </select>
          </Field>

          <Field
            label="Deadline"
            htmlFor="task-deadline"
            error={errors.deadline}
            hint="Optional target date."
          >
            <div className="relative">
              <CalendarDays
                size={17}
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />

              <input
                id="task-deadline"
                name="deadline"
                type="date"
                className={`input pl-10 ${
                  errors.deadline ? 'input-error' : ''
                }`}
                value={form.deadline}
                onChange={setField('deadline')}
                aria-invalid={Boolean(errors.deadline)}
                aria-describedby={
                  errors.deadline
                    ? 'task-deadline-error'
                    : undefined
                }
              />
            </div>
          </Field>

          <Field
            label="Assigned to"
            htmlFor="task-assignee"
            hint="Choose who will handle this task."
          >
            <div className="relative">
              <UserRound
                size={17}
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />

              <select
                id="task-assignee"
                name="assignedUserId"
                className="input pl-10"
                value={form.assignedUserId}
                onChange={setField('assignedUserId')}
                disabled={usersLoading}
              >
                <option value="">
                  {usersLoading
                    ? 'Loading users...'
                    : 'Nobody yet'}
                </option>

                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name}
                  </option>
                ))}
              </select>
            </div>

            {usersError && (
              <p
                className="mt-1.5 text-xs leading-5 text-amber-700"
                role="status"
              >
                {usersError}
              </p>
            )}
          </Field>
        </div>

        <div className="border-t border-slate-100 pt-5">
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button
              type="button"
              className="btn-ghost w-full sm:w-auto"
              onClick={onClose}
              disabled={saving}
            >
              Cancel
            </button>

            <button
              type="submit"
              className="btn-primary w-full sm:w-auto"
              disabled={saving}
              aria-busy={saving}
            >
              {saving ? (
                <>
                  <Loader2
                    size={16}
                    className="animate-spin"
                    aria-hidden="true"
                  />
                  <span>
                    {isEditing ? 'Saving...' : 'Creating...'}
                  </span>
                </>
              ) : (
                <>
                  {isEditing ? (
                    <Check size={16} aria-hidden="true" />
                  ) : (
                    <ClipboardList
                      size={16}
                      aria-hidden="true"
                    />
                  )}

                  <span>
                    {isEditing ? 'Save changes' : 'Add task'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
}