import { Loader2 } from 'lucide-react';

export default function Spinner({
  label = 'Loading',
  compact = false,
}) {
  return (
    <div
      className={[
        'flex items-center justify-center',
        compact ? 'gap-2 py-2' : 'gap-3 py-10',
      ].join(' ')}
      role="status"
      aria-live="polite"
    >
      <span
        className={[
          'flex shrink-0 items-center justify-center rounded-xl',
          'bg-pine/[0.08] text-pine',
          compact ? 'h-8 w-8' : 'h-10 w-10',
        ].join(' ')}
      >
        <Loader2
          className="animate-spin"
          size={compact ? 17 : 20}
          strokeWidth={2}
          aria-hidden="true"
        />
      </span>

      <span className="text-sm font-medium text-muted">
        {label}...
      </span>
    </div>
  );
}