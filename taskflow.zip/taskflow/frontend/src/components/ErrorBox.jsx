
import {
  AlertCircle,
  RotateCcw,
} from 'lucide-react';

export default function ErrorBox({
  message,
  onRetry,
}) {
  if (!message) return null;

  return (
    <div
      className="flex flex-col gap-3 rounded-2xl border border-red-200 bg-red-50/90 p-4 text-sm text-red-700 shadow-sm shadow-red-100/60 sm:flex-row sm:items-center"
      role="alert"
      aria-live="assertive"
    >
      {/* ICON + MESSAGE */}
      <div className="flex min-w-0 flex-1 items-start gap-3">
        <div
          aria-hidden="true"
          className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-100 text-red-600"
        >
          <AlertCircle size={18} strokeWidth={2.2} />
        </div>

        <div className="min-w-0">
          <p className="font-semibold text-red-800">
            Something went wrong
          </p>

          <p className="mt-0.5 break-words leading-5 text-red-700/85">
            {message}
          </p>
        </div>
      </div>

      {/* RETRY */}
      {typeof onRetry === 'function' && (
        <button
          type="button"
          onClick={onRetry}
          className="inline-flex min-h-10 shrink-0 items-center justify-center gap-2 rounded-xl border border-red-200 bg-white px-3.5 py-2 text-sm font-semibold text-red-700 shadow-sm transition-colors duration-200 hover:border-red-300 hover:bg-red-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-400 focus-visible:ring-offset-2 active:bg-red-100 sm:self-center"
        >
          <RotateCcw
            size={15}
            strokeWidth={2.2}
            aria-hidden="true"
          />

          <span>Try again</span>
        </button>
      )}
    </div>
  );
}
