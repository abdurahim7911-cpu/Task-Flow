import { useState } from 'react';
import {
  CalendarDays,
  Check,
  FileText,
  FolderPlus,
  Loader2,
  Save,
} from 'lucide-react';

import Modal from './Modal.jsx';
import Field from './Field.jsx';
import ErrorBox from './ErrorBox.jsx';

import api, {
  parseError,
} from '../api/client.js';

import { toDateInput } from '../utils/format.js';

export default function ProjectForm({
  project,
  onClose,
  onSaved,
}) {
  const isEditing = Boolean(project);

  const [form, setForm] = useState({
    title: project?.title || '',
    description: project?.description || '',
    status: project?.status || 'ACTIVE',
    deadline: toDateInput(project?.deadline),
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [saving, setSaving] = useState(false);

  const setField = (key) => (event) => {
    const value = event.target.value;

    setForm((current) => ({
      ...current,
      [key]: value,
    }));

    setErrors((current) => {
      if (!current[key]) return current;

      const next = { ...current };
      delete next[key];

      return next;
    });

    if (serverError) {
      setServerError('');
    }
  };

  const validate = () => {
    const nextErrors = {};
    const title = form.title.trim();

    if (!title) {
      nextErrors.title = 'Title is required';
    } else if (title.length < 2) {
      nextErrors.title =
        'Title must be at least 2 characters';
    } else if (title.length > 120) {
      nextErrors.title =
        'Title must be at most 120 characters';
    }

    if (form.description.length > 2000) {
      nextErrors.description =
        'Description must be at most 2000 characters';
    }

    if (
      form.deadline &&
      Number.isNaN(Date.parse(form.deadline))
    ) {
      nextErrors.deadline = 'Enter a valid date';
    }

    return nextErrors;
  };

  const submit = async (event) => {
    event.preventDefault();

    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      return;
    }

    setSaving(true);
    setServerError('');

    try {
      const body = {
        title: form.title.trim(),
        description: form.description.trim() || null,
        status: form.status,
        deadline: form.deadline || null,
      };

      const response = isEditing
        ? await api.patch(
            `/projects/${project.id}`,
            body
          )
        : await api.post('/projects', body);

      onSaved(response.data.project);
    } catch (error) {
      const parsed = parseError(error);

      setErrors(parsed.fields || {});
      setServerError(parsed.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={isEditing ? 'Edit project' : 'New project'}
      onClose={onClose}
    >
      <form
        onSubmit={submit}
        noValidate
        className="space-y-5"
      >
        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
            {isEditing ? (
              <Save size={18} strokeWidth={2.2} />
            ) : (
              <FolderPlus size={18} strokeWidth={2.2} />
            )}
          </div>

          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-900">
              {isEditing
                ? 'Update project details'
                : 'Create a new project'}
            </p>

            <p className="mt-0.5 text-xs leading-5 text-slate-500">
              {isEditing
                ? 'Keep the project information up to date.'
                : 'Add the basic information to start tracking your work.'}
            </p>
          </div>
        </div>

        <ErrorBox message={serverError} />

        <Field
          label="Title"
          htmlFor="project-title"
          error={errors.title}
          hint="Use a short, clear project name."
        >
          <div className="relative">
            <FolderPlus
              size={17}
              strokeWidth={2}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />

            <input
              id="project-title"
              name="title"
              type="text"
              className={`input pl-10 ${
                errors.title ? 'input-error' : ''
              }`}
              value={form.title}
              onChange={setField('title')}
              placeholder="e.g. Website redesign"
              autoFocus
              autoComplete="off"
              maxLength={120}
              aria-invalid={Boolean(errors.title)}
              aria-describedby={
                errors.title
                  ? 'project-title-error'
                  : undefined
              }
            />
          </div>
        </Field>

        <Field
          label="Description"
          htmlFor="project-description"
          error={errors.description}
          hint="Optional. Add context about the project."
        >
          <div className="relative">
            <FileText
              size={17}
              strokeWidth={2}
              className="pointer-events-none absolute left-3.5 top-3.5 text-slate-400"
              aria-hidden="true"
            />

            <textarea
              id="project-description"
              name="description"
              className={`input min-h-[110px] resize-y pl-10 ${
                errors.description ? 'input-error' : ''
              }`}
              rows={4}
              value={form.description}
              onChange={setField('description')}
              placeholder="What is this project about?"
              maxLength={2000}
              aria-invalid={Boolean(errors.description)}
              aria-describedby={
                errors.description
                  ? 'project-description-error'
                  : undefined
              }
            />
          </div>

          <div className="mt-1.5 flex justify-end">
            <span className="text-[11px] text-slate-400">
              {form.description.length}/2000
            </span>
          </div>
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field
            label="Status"
            htmlFor="project-status"
            hint="Current project state."
          >
            <select
              id="project-status"
              name="status"
              className="input"
              value={form.status}
              onChange={setField('status')}
            >
              <option value="ACTIVE">Active</option>
              <option value="COMPLETED">Completed</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </Field>

          <Field
            label="Deadline"
            htmlFor="project-deadline"
            error={errors.deadline}
            hint="Optional target date."
          >
            <div className="relative">
              <CalendarDays
                size={17}
                strokeWidth={2}
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />

              <input
                id="project-deadline"
                name="deadline"
                type="date"
                className={`input pl-10 ${
                  errors.deadline ? 'input-error' : ''
                }`}
                value={form.deadline}
                onChange={setField('deadline')}
                aria-invalid={Boolean(errors.deadline)}
                aria-describedby={
                  errors.deadline
                    ? 'project-deadline-error'
                    : undefined
                }
              />
            </div>
          </Field>
        </div>

        <div className="border-t border-slate-100 pt-5">
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button
              type="button"
              className="btn-ghost w-full sm:w-auto"
              onClick={onClose}
              disabled={saving}
            >
              Cancel
            </button>

            <button
              type="submit"
              className="btn-primary w-full sm:w-auto"
              disabled={saving}
              aria-busy={saving}
            >
              {saving ? (
                <>
                  <Loader2
                    size={16}
                    className="animate-spin"
                    strokeWidth={2.3}
                    aria-hidden="true"
                  />
                  <span>
                    {isEditing ? 'Saving...' : 'Creating...'}
                  </span>
                </>
              ) : (
                <>
                  {isEditing ? (
                    <Check
                      size={16}
                      strokeWidth={2.3}
                      aria-hidden="true"
                    />
                  ) : (
                    <FolderPlus
                      size={16}
                      strokeWidth={2.3}
                      aria-hidden="true"
                    />
                  )}

                  <span>
                    {isEditing ? 'Save changes' : 'Create project'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
}