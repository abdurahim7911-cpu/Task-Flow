export default function Field({
  label,
  error,
  children,
  hint,
  htmlFor,
}) {
  return (
    <div className="min-w-0">
      {label && (
        <label
          htmlFor={htmlFor}
          className="block text-sm font-semibold text-slate-800"
        >
          {label}
        </label>
      )}

      <div className={label ? 'mt-2' : ''}>
        {children}
      </div>

      {error ? (
        <p
          id={htmlFor ? `${htmlFor}-error` : undefined}
          className="mt-1.5 text-xs font-medium leading-5 text-signal"
          role="alert"
        >
          {error}
        </p>
      ) : hint ? (
        <p
          id={htmlFor ? `${htmlFor}-hint` : undefined}
          className="mt-1.5 text-xs leading-5 text-muted"
        >
          {hint}
        </p>
      ) : null}
    </div>
  );
}