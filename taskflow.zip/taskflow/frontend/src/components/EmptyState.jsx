
export default function EmptyState({
  icon: Icon,
  title,
  text,
  action,
}) {
  return (
    <div
      role="status"
      className="panel relative flex min-w-0 flex-col items-center overflow-hidden px-5 py-10 text-center sm:px-8 sm:py-14"
    >
      {/* DECORATIVE GLOW */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-0 h-32 w-48 -translate-x-1/2 rounded-full bg-pine/[0.06] blur-3xl"
      />

      {/* ICON */}
      {Icon && (
        <div className="relative mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-slate-200 bg-gradient-to-br from-white to-slate-50 text-pine shadow-sm">
          <Icon
            size={28}
            strokeWidth={1.8}
            aria-hidden="true"
          />
        </div>
      )}

      {/* TEXT */}
      <div className="relative w-full max-w-lg">
        {title && (
          <h3 className="break-words font-display text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
            {title}
          </h3>
        )}

        {text && (
          <p className="mx-auto mt-2 max-w-sm break-words text-sm leading-6 text-muted">
            {text}
          </p>
        )}
      </div>

      {/* ACTION */}
      {action && (
        <div className="relative mt-6 flex w-full flex-col items-stretch justify-center gap-2 sm:w-auto sm:flex-row sm:items-center">
          {action}
        </div>
      )}
    </div>
  );
}
