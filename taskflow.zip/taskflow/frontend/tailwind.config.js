/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#F2F4F1',
        ink: '#17231F',
        pine: { DEFAULT: '#1F5F4A', dark: '#164536', soft: '#DCE9E2' },
        signal: { DEFAULT: '#D9482B', soft: '#FBE3DC' },
        amber: { soft: '#F7ECCB', ink: '#7A5A0A' },
        line: '#D5DBD4',
        muted: '#5E6B66',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['"Hanken Grotesk"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
